package com.security.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.security.entity.UserEntity;
import com.security.repo.UserRepo;

@Service
public class UserServiceImpl implements UserDetailsService {
	
	@Autowired
	UserRepo repo;


	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		List<UserEntity> userList = repo.findByUserName(username);
		if(userList==null && userList.size()==0) {
			throw new UsernameNotFoundException(username);
		}
		UserEntity userentity = userList.get(0);
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(userentity.getRole()));
		User user = new User( userentity.getUserName(), userentity.getPassword(),authorities);
		return  user;
	}

}
