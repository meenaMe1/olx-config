package com.security.service;

import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.security.dto.User;

public interface UserDetailsServiceerr {
	
	
	public User loadUserByUserName(String username) throws UsernameNotFoundException;

}
