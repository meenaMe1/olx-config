package com.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.security.dto.AuthenticationRequest;
import com.security.utils.JwtUtils;

@RestController
public class UserController {
	
	@Autowired
	AuthenticationManager authenticateManager;
	
	@Autowired
	JwtUtils jwtUtil;
	
	@GetMapping("/all")
	public String viewAll() {
	return "Hello All";
	}

	 @GetMapping("/employee")
	public String viewEmployee() {
	return "Hello Employee";
	}

	 @GetMapping("/admin")
	public String viewAdmin() {
	return "Hello Admin";
	}
	 
	 @PostMapping(value="/aunthenticate", consumes=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<String> authenticate (@RequestBody AuthenticationRequest authenticate){
		 try {
			 
			 authenticateManager.authenticate(new UsernamePasswordAuthenticationToken(authenticate.getUserName(), authenticate.getPassword())); 
		 }catch(Exception e) {
			throw new BadCredentialsException(authenticate.getUserName());
		 }
		 String jwtToken = jwtUtil.generateToken(authenticate.getUserName());
		return new ResponseEntity<String>(jwtToken,HttpStatus.OK);
		 
	 }
	 
	 

}
