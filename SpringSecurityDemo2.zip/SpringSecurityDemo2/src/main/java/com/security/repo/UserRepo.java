package com.security.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.security.entity.UserEntity;

public interface UserRepo extends JpaRepository<UserEntity, Integer> {

	
	public List<UserEntity> findByUserName(String username);

}
