package day6;

public class Y extends X{
	int y=20;
}
