package day6;

public class AXIS extends Bank {
	public double returnIR() {
		return 10;
	}
}
