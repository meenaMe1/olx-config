package day6;

public class C extends A,B{

	public void add() {
		System.out.println(a+b);
	}
	
}
