package day6;

public interface InterfaceA {

}
