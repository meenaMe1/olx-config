package day6;

public class PolymorphismTest {
	public static void main(String[] args) {
		
		Bank bank= new Bank();
		
		Bank sbi = new SBI();
		Bank icici = new ICICI();
		Bank axis = new AXIS();

		
		System.out.println(sbi.returnIR());
		System.out.println(icici.returnIR());
		System.out.println(axis.returnIR());
	
	}

}
