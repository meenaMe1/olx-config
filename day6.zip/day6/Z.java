package day6;

public class Z extends Y{

	int z=30;
	
	public void add() {
		System.out.println(x+y+z);
	}
}
