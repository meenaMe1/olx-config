package day6;

public interface InterfaceExample {

	public void add();

	
}
