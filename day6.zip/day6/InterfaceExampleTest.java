package day6;

public class InterfaceExampleTest implements InterfaceExample{

	@Override
	public void add() {
		System.out.println("Adding Two Numbers");
	}
	
}
