package day6;

//public interface InterfaceTest extends InterfaceExample,InterfaceA{
public class InterfaceTest implements InterfaceExample,InterfaceA{

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}
	
	
//	InterfaceExample in= new InterfaceExample();
	
}
