package day6;

public class RBI {

	public int ir=0;
}
