package day6;

public class ICICI extends Bank{

	
	public double returnIR(int i) {
		return 5;
	}
	
}
