package day6;

public class MultipleInheritanceTest {

	
	public static void main(String[] args) {
		Z objZ= new Z();
		objZ.add();
}
	
	
}
