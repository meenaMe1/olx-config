package day6;

public class SBI extends Bank{
//	public double returnIR() {
//		return 3.5;
//	}
	
}
