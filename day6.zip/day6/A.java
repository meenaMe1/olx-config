package day6;

public class A {

	int a=10;
}
