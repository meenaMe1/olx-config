package day6;

public class B {
 int b=20;
}
