package day6;

public class AbstractExampleTest extends AbstractExample{

	public static void main(String[] args) {

//		AbstractExample a= new AbstractExample();
		
	}

	@Override
	public void printIR() {
		System.out.println(4.5);
	}

}
