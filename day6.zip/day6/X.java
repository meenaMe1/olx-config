package day6;

public class X {
 int x=10;
}
