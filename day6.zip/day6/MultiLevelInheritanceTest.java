package day6;

public class MultiLevelInheritanceTest {

	syso
	
}
