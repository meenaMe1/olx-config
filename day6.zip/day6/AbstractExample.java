package day6;

abstract public class AbstractExample {

	public int a=10;
	
	abstract public void printIR();
	public void calculateIR() {
		
	}
}
