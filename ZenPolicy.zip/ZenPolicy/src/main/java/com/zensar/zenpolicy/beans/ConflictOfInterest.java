package com.zensar.zenpolicy.beans;

import org.springframework.stereotype.Component;

@Component
public class ConflictOfInterest {

	private String icon;
	private String title;
	private String description;
	private String policyUrl;
	
	public ConflictOfInterest() {
		super();
	}

	public ConflictOfInterest(String icon, String title, String description, String policyUrl) {
		super();
		this.icon = icon;
		this.title = title;
		this.description = description;
		this.policyUrl = policyUrl;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPolicyUrl() {
		return policyUrl;
	}

	public void setPolicyUrl(String policyUrl) {
		this.policyUrl = policyUrl;
	}

	@Override
	public String toString() {
		return "ConflictOfInterest [icon=" + icon + ", title=" + title + ", description=" + description + ", policyUrl="
				+ policyUrl + "]";
	}
	
	
}
