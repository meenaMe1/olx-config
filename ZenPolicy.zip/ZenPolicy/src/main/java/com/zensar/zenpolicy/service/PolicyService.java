package com.zensar.zenpolicy.service;

import java.util.List;

import com.zensar.zenpolicy.beans.PolicyDeclaration;
import com.zensar.zenpolicy.beans.Questions;

public interface PolicyService {

	public List<Questions> getQuestions();

	public List<Questions> insertUserQuestion(PolicyDeclaration policyDeclaration);
}
