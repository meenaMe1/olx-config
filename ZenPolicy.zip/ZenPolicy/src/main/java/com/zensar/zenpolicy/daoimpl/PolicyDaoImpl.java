package com.zensar.zenpolicy.daoimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zensar.zenpolicy.beans.Answers;
import com.zensar.zenpolicy.beans.PolicyDeclaration;
import com.zensar.zenpolicy.beans.Questions;
import com.zensar.zenpolicy.beans.Trails;
import com.zensar.zenpolicy.dao.PolicyDao;

@Repository
@Transactional(noRollbackFor = Exception.class)
public class PolicyDaoImpl implements PolicyDao {

	@Autowired
	private EntityManagerFactory entityManager;
	@Autowired
	private com.zensar.zenpolicy.constants.QueryConstants queryConstants;
	@PersistenceContext(unitName = "MYSQL_DB")
	private EntityManager mySqlSession;
	@Value("${userId}")
	private int userId;
	
	Questions questions = null;

	@Override
	public List<Questions> getQuestions() {
		EntityManager session = entityManager.createEntityManager();
		Answers answers = null;
		Trails trails = null;
		List<Questions> qList = new ArrayList<>();
		List<Answers> aList = new ArrayList<>();
		List<Trails> trailList = new ArrayList<>();

		try {
			List<Object[]> resultSet = session.createNativeQuery(queryConstants.getQuestionsList()).getResultList();
			for (Object[] result : resultSet) {
				questions = new Questions();
				questions.setQuestionId((int) result[0]);
				questions.setQuestionText(result[1] != null ? ((String) result[1]).trim() : "");
				questions.setAnswer(getAnswers());
				qList.add(questions);
			}
		} catch (Exception e) {
			questions = null;
		} finally {
			if (session.isOpen())
				session.close();
		}

		return qList;
	}

	public List<Answers> getAnswers() {
		EntityManager session = entityManager.createEntityManager();
		Answers answers = null;
		Trails trails = null;
		List<Answers> aList = new ArrayList<>();
		List<Trails> trailList = new ArrayList<>();

		List<Object[]> rs = session.createNativeQuery(queryConstants.getAnswersList())
				.setParameter("questionId", questions.getQuestionId()).getResultList();
		for (Object[] result : rs) {
			answers = new Answers();
			answers.setAnswerId((int) result[0]);
			answers.setAnswerText(result[2] != null ? ((String) result[2]).trim() : "");
			answers.setIsAnswerTrail((int) result[3]);
			answers.setTrailList(trailList);
			aList.add(answers);
		}

		List<Object[]> trailsResultSet = session.createNativeQuery(queryConstants.getTrailsList())
				.setParameter("answerId", answers.getAnswerId()).getResultList();
		for (Object[] result : trailsResultSet) {
			trails = new Trails();
			trails.setTrailId((int) result[0]);
			trails.setIsFreeText((int) result[2]);
			trails.setTrailQuestionText(result[3] != null ? ((String) result[3]).trim() : "");
			trailList.add(trails);
		}
		session.close();
		return aList;
	}

	@Override
	public List<Questions> insertUserQuestion(PolicyDeclaration policyDeclaration) {
		int result = 0;
		Questions question = null;
		Answers answer = null;
		Iterator itr = policyDeclaration.getQuestion().iterator();
		while(itr.hasNext()){
			question = (Questions) itr.next();
			Iterator iterator = question.getAnswer().iterator();
			while(iterator.hasNext()) {
				answer = (Answers) iterator.next();			
				}
		try {
			result = mySqlSession.createNativeQuery(queryConstants.getInsertUserQuestion())
					.setParameter("userId", userId)
					.setParameter("questionId", question.getQuestionId())
					.setParameter("answerId", answer.getAnswerId()).executeUpdate();
		} catch (Exception e) {
			result = 0;
		} finally {
			if (mySqlSession.isOpen())
				mySqlSession.close();
		}
		insertUserAnswerTrail(answer);
		}
		return policyDeclaration.getQuestion();
	}

	public void insertUserAnswerTrail(Answers answer) {
		int result = 0;
		Trails trail = null;
		try {
			Iterator itr = answer.getTrailList().iterator();
			while(itr.hasNext()){
				trail = (Trails) itr.next();
			result = mySqlSession.createNativeQuery(queryConstants.getInsertUserAnswerTrail())
					.setParameter("userId", 61808)
					.setParameter("answerId", answer.getAnswerId())
					.setParameter("trailId", trail.getTrailId())
					.setParameter("trailText", trail.getTrailQuestionText())
					.executeUpdate();
			}
		} catch (Exception e) {
			result = 0;
		} finally {
			if (mySqlSession.isOpen())
				mySqlSession.close();
		}
	}

}
