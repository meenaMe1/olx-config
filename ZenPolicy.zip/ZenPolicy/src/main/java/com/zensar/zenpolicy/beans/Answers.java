package com.zensar.zenpolicy.beans;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Answers {

	private int answerId;
	private String answerText;
	private int isAnswerTrail;
	//@OneToMany(cascade = {CascadeType.PERSIST, CascadeType.REMOVE },
		//	fetch=FetchType.LAZY,mappedBy = "answer")
	private List<Trails> trailList;
	//@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	//@JoinColumn(name = "questionId")
	//private Questions question;
	
	public Answers() {
		super();
	}

	public Answers(int answerId, String answerText, int isAnswerTrail, List<Trails> trailList) {
		super();
		this.answerId = answerId;
		this.answerText = answerText;
		this.isAnswerTrail = isAnswerTrail;
		this.trailList = trailList;
		//this.question = question;
	}

	public int getAnswerId() {
		return answerId;
	}

	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}

	public String getAnswerText() {
		return answerText;
	}

	public void setAnswerText(String answerText) {
		this.answerText = answerText;
	}

	public int getIsAnswerTrail() {
		return isAnswerTrail;
	}

	public void setIsAnswerTrail(int isAnswerTrail) {
		this.isAnswerTrail = isAnswerTrail;
	}

	public List<Trails> getTrailList() {
		return trailList;
	}

	public void setTrailList(List<Trails> trailList) {
		this.trailList = trailList;
	}

	/*
	 * public Questions getQuestion() { return question; }
	 * 
	 * public void setQuestion(Questions question) { this.question = question; }
	 */
	@Override
	public String toString() {
		return "Answers [answerId=" + answerId + ", answerText=" + answerText + ", isAnswerTrail="
				+ isAnswerTrail + ", trailList=" + trailList + /* ", question=" + question + */ "]";
	}
	
	
}
