package com.zensar.zenpolicy.beans;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class PolicyDeclaration {

	private String icon;
	private String title;
	private String description;
   // @OneToOne(cascade = {CascadeType.ALL},fetch = FetchType.LAZY)
   // @JoinColumn(name = "questionId")
	private List<Questions> question;
    
	public PolicyDeclaration() {
		super();
	}

	public PolicyDeclaration(String icon, String title, String description, List<Questions> question) {
		super();
		this.icon = icon;
		this.title = title;
		this.description = description;
		this.question = question;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Questions> getQuestion() {
		return question;
	}

	public void setQuestion(List<Questions> question) {
		this.question = question;
	}

	@Override
	public String toString() {
		return "PolicyDeclaration [icon=" + icon + ", title=" + title + ", description=" + description + ", question=" + question + "]";
	}
	
}
