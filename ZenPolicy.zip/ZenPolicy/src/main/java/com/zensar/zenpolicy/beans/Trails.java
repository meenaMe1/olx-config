package com.zensar.zenpolicy.beans;

import org.springframework.stereotype.Component;

@Component
public class Trails {

	private int trailId;
	private String trailQuestionText;
	private int isFreeText;
	//@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	//@JoinColumn(name = "answerId")
	//private Answers answer;

	public Trails() {
		super();
	}

	public Trails(int trailId, String trailQuestionText, int isFreeText) {
		super();
		this.trailId = trailId;
		this.trailQuestionText = trailQuestionText;
		this.isFreeText = isFreeText;
		//this.answer = answer;
	}

	public int getTrailId() {
		return trailId;
	}

	public void setTrailId(int trailId) {
		this.trailId = trailId;
	}

	public String getTrailQuestionText() {
		return trailQuestionText;
	}

	public void setTrailQuestionText(String trailQuestionText) {
		this.trailQuestionText = trailQuestionText;
	}

	public int getIsFreeText() {
		return isFreeText;
	}

	public void setIsFreeText(int isFreeText) {
		this.isFreeText = isFreeText;
	}

	/*
	 * public Answers getAnswer() { return answer; }
	 * 
	 * public void setAnswer(Answers answer) { this.answer = answer; }
	 */

	@Override
	public String toString() {
		return "Trails [trailId=" + trailId + ", trailQuestionText=" + trailQuestionText + ", isFreeText=" + isFreeText
				+ /* ", answer=" + answer + */"]";
	}
}
