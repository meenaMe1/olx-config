package com.zensar.zenpolicy.constants;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:exit-zentalent-queries.properties"})
@ConfigurationProperties
public class QueryConstants {

	private String questionsList;
	private String answersList;
	private String trailsList;
	private String insertUserQuestion;
	private String insertUserAnswerTrail;
	
	public String getQuestionsList() {
		return questionsList;
	}

	public void setQuestionsList(String questionsList) {
		this.questionsList = questionsList;
	}

	public String getAnswersList() {
		return answersList;
	}

	public void setAnswersList(String answersList) {
		this.answersList = answersList;
	}

	public String getTrailsList() {
		return trailsList;
	}

	public void setTrailsList(String trailsList) {
		this.trailsList = trailsList;
	}

	public String getInsertUserQuestion() {
		return insertUserQuestion;
	}

	public void setInsertUserQuestion(String insertUserQuestion) {
		this.insertUserQuestion = insertUserQuestion;
	}

	public String getInsertUserAnswerTrail() {
		return insertUserAnswerTrail;
	}

	public void setInsertUserAnswerTrail(String insertUserAnswerTrail) {
		this.insertUserAnswerTrail = insertUserAnswerTrail;
	}
	
	
}
