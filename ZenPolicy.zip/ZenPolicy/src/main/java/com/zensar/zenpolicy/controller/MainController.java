package com.zensar.zenpolicy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenpolicy.beans.ConflictOfInterest;
import com.zensar.zenpolicy.beans.Details;
import com.zensar.zenpolicy.beans.PolicyDeclaration;
import com.zensar.zenpolicy.beans.Questions;
import com.zensar.zenpolicy.beans.Status;
import com.zensar.zenpolicy.beans.ZenPolicy;
import com.zensar.zenpolicy.constants.GlobalConstant;
import com.zensar.zenpolicy.service.PolicyService;

@RestController
@RequestMapping("/zenpolicy")
public class MainController {

	@Autowired 
	private PolicyService policyService;
	@Autowired
	private GlobalConstant globalConstant;
	@Value("${noDeclarationText}")
	private String noDeclarationText;
	@Value("${yesDeclarationText}")
	private String yesDeclarationText;
	@Value("${description}")
	private String text;
	
	@PostMapping("/status")
	public ZenPolicy showStatus(ZenPolicy zenPolicy,Status status,Details details,ConflictOfInterest conflictOfInterest,PolicyDeclaration policyDeclaration,Questions questions) {
		status.setStatusCode(01);
		status.setStatusMessage("Request successfully processed");
		zenPolicy.setStatus(status);
		conflictOfInterest.setIcon(globalConstant.getIconUrl());
		conflictOfInterest.setTitle("Policy Declaration");
		conflictOfInterest.setDescription(text);
		conflictOfInterest.setPolicyUrl(globalConstant.getPolicyUrl());
		details.setConflictOfInterest(conflictOfInterest);
		policyDeclaration.setIcon(globalConstant.getIconUrl());
		policyDeclaration.setTitle("Policy Declaration");
		policyDeclaration.setDescription(text);
		policyDeclaration.setQuestion(policyService.getQuestions());
		details.setPolicyDeclaration(policyDeclaration);
		details.setAllNoDeclarationText(noDeclarationText);
		details.setAnyYesDeclarationText(yesDeclarationText);
		zenPolicy.setDetails(details);
		return zenPolicy;
	}

	@PostMapping("/insert")
	public List<Questions> insertUserQuestion(@RequestBody PolicyDeclaration policyDeclaration) {
		return policyService.insertUserQuestion(policyDeclaration);
	}
}
