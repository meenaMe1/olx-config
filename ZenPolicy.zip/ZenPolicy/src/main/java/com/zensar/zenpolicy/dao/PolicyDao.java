package com.zensar.zenpolicy.dao;

import java.util.List;

import com.zensar.zenpolicy.beans.PolicyDeclaration;
import com.zensar.zenpolicy.beans.Questions;

public interface PolicyDao {

	public List<Questions> getQuestions();

	public List<Questions> insertUserQuestion(PolicyDeclaration policyDeclaration);
	
}
