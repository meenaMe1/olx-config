package com.zensar.zenpolicy.beans;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Questions {

	private int questionId;
	private String questionText;
	//@OneToMany(cascade = {CascadeType.PERSIST, CascadeType.REMOVE },
		//	fetch=FetchType.LAZY,mappedBy = "question")
	private List<Answers> answer;
	
	public Questions() {
		super();
	}

	public Questions(int questionId, String questionText, List<Answers> answer) {
		super();
		this.questionId = questionId;
		this.questionText = questionText;
		this.answer = answer;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public List<Answers> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answers> answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Questions [questionId=" + questionId + ", questionText=" + questionText + ", answer=" + answer + "]";
	}
	
	
}
