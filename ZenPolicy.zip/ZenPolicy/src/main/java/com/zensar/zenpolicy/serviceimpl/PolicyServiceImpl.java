package com.zensar.zenpolicy.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.zenpolicy.beans.PolicyDeclaration;
import com.zensar.zenpolicy.beans.Questions;
import com.zensar.zenpolicy.dao.PolicyDao;
import com.zensar.zenpolicy.service.PolicyService;

@Service
public class PolicyServiceImpl implements PolicyService{

	@Autowired
	PolicyDao policyDao;
	
	@Override
	public List<Questions> getQuestions() {
		return policyDao.getQuestions();
	}

	@Override
	public List<Questions> insertUserQuestion(PolicyDeclaration policyDeclaration) {
		return policyDao.insertUserQuestion(policyDeclaration);
	}

}
