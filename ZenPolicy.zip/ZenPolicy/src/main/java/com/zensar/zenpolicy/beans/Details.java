package com.zensar.zenpolicy.beans;

import org.springframework.stereotype.Component;

@Component
public class Details {

	private ConflictOfInterest conflictOfInterest;
	private PolicyDeclaration policyDeclaration;
	private String allNoDeclarationText;
	private String anyYesDeclarationText;
	public ConflictOfInterest getConflictOfInterest() {
		return conflictOfInterest;
	}
	public void setConflictOfInterest(ConflictOfInterest conflictOfInterest) {
		this.conflictOfInterest = conflictOfInterest;
	}
	public PolicyDeclaration getPolicyDeclaration() {
		return policyDeclaration;
	}
	public void setPolicyDeclaration(PolicyDeclaration policyDeclaration) {
		this.policyDeclaration = policyDeclaration;
	}
	public String getAllNoDeclarationText() {
		return allNoDeclarationText;
	}
	public void setAllNoDeclarationText(String allNoDeclarationText) {
		this.allNoDeclarationText = allNoDeclarationText;
	}
	public String getAnyYesDeclarationText() {
		return anyYesDeclarationText;
	}
	public void setAnyYesDeclarationText(String anyYesDeclarationText) {
		this.anyYesDeclarationText = anyYesDeclarationText;
	}

	
}