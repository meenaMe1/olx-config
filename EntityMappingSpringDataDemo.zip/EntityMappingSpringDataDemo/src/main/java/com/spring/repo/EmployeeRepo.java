package com.spring.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.entity.one_to_one.EmployeeEntity;

public interface EmployeeRepo extends JpaRepository<EmployeeEntity, Long>{

	@Query("SELECT e FROM EmployeeEntity as e WHERE e.profile.experience >=: 1")
	List<EmployeeEntity> findAllByExperience(double experience);
	
	
	

}
