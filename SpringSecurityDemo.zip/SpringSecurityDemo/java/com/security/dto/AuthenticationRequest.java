package com.security.dto;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@AllArgsConstructor
@Component
public class AuthenticationRequest {
	

	private String userName;
	
	
	private String password;

}
