package com.security.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.security.dto.User;
import com.security.entity.UserEntity;
import com.security.repo.UserRepo;
import com.security.service.UserService;

@Service
public class UserDetailsServiceImpl implements UserServiceD{
	
	@Autowired
	UserRepo repo;

	@Override
	public User loadUserByUserName(String username) throws UsernameNotFoundException {
		List<UserEntity> userList = repo.findByUserName(username);
	if(userList==null && userList.size()==0) {
		throw new UsernameNotFoundException(username);
	}
	UserEntity userentity = userList.get(0);
	List<GrantedAuthority> authorities = new ArrayList<>();
	authorities.add(new SimpleGrantedAuthority(userentity.getRole()));
	User user = new User( userentity.getUserName(), userentity.getPassword(), userentity.getRole());
	return user;
	}

}
