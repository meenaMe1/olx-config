package Checkout;

import org.testng.annotations.Test;

import MyApp.GoogleReusable;

public class CheckoutModule {

	
	
	@Test
	public void TC_001() {
		GoogleReusable gr= new GoogleReusable();
		
		gr.startBrowser("CH");
		gr.launchURL("http://google.com");
		gr.search("Automation");
		gr.closeBrowser();
	}
	
	@Test
	public void TC_002() {
		GoogleReusable gr= new GoogleReusable();
		
		gr.startBrowser("CH");
		gr.launchURL("http://google.com");
		gr.search("Jeans");
		gr.closeBrowser();
	}
	
	@Test
	public void TC_003() {
		GoogleReusable gr= new GoogleReusable();
		
		gr.startBrowser("CH");
		gr.launchURL("http://automationpractice.com");
		gr.searchOnAP("Dress");
//		gr.closeBrowser();
	
		
	}
	
	
	
}
