
public class GenericMethods {

	
	
}
