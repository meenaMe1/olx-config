package com.olx.advertise.dto;

import java.util.Date;

import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Component
@ApiModel(value ="Advertise model holds information about a olx advertisement")
public class Advertise {
	
	private int id;
	@ApiModelProperty(value="Advertise Title")
	private String title;
	private double price;
	private String category;
	private String description;
	private Date createdDate;
	
	private Date modifiedDate;
	private String status;
	
	

}
