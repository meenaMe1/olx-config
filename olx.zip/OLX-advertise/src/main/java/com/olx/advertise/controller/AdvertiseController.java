package com.olx.advertise.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.olx.advertise.delegate.UserServiceDelegate;
import com.olx.advertise.dto.Advertise;
import com.olx.advertise.service.AdvertiseService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin(origins="*")
public class AdvertiseController {
	
	@Autowired
	AdvertiseService advertiseService;
	
	@Autowired
	UserServiceDelegate service;
	
	@PostMapping(value ="/advertise", consumes={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="create advertise" , notes="This service create advertise")
	public ResponseEntity<Advertise> createAdvertise(@RequestHeader("Authorization") String authToken,@RequestBody Advertise advertise) {
		Advertise advertsie = new Advertise();
		if(service.isLoggedInUser(authToken)) {
			advertiseService.createAdvertise(authToken, advertise);
			return new ResponseEntity(advertsie,HttpStatus.OK);
			}
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}
	
	
	@PutMapping(value ="/advertise", consumes={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="update advertise" , notes="This service update advertise")
	public ResponseEntity<Advertise> updateAvertisement(@RequestHeader("auth-token") String authToken,@RequestBody Advertise advertise) {
	
		Advertise advertsie =null;
		if(authToken.equalsIgnoreCase("Mb50026")) {
			 //advertise = new Advertise(1, "Laptop", 4000.00, "electronics", "test", new Date(), new Date(), "Closed");
			advertiseService.updateAvertisement(authToken, advertise);
			return new ResponseEntity(advertsie,HttpStatus.OK);
			}
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}
	
	@GetMapping(value ="/user/advertise", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="get all advertise" , notes="This service fetch all advertise")
	public ResponseEntity<List<Advertise>> getAllUserAdvertisement(@RequestHeader("auth-token") String authToken) {
		List<Advertise> advertiseList=new ArrayList<>();
		Advertise advertise = new Advertise(1, "Laptop", 4000.00, "electronics", "test", new Date(), new Date(), "Closed");
		advertiseList.add(advertise);
		if(authToken.equalsIgnoreCase("Mb50026")) {
			return new ResponseEntity(advertiseList, HttpStatus.OK);
			}
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}
	
	
	@GetMapping(value ="/user/advertise/{postId}", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="advertise of a specific user by Id" , notes="This service advertise of a specific user by Id")
	public ResponseEntity<Advertise> getUserAdvertisementById(@RequestHeader("auth-token") String authToken , @PathVariable("id") int postId) {
		if(authToken.equalsIgnoreCase("Mb50026")) {
			//Advertise advertise = new Advertise(1, "Laptop", 4000.00, "electronics", "test", new Date(), new Date(), "Closed");
			Advertise advertise =advertiseService.getUserAdvertisementById(authToken, postId);
			return new ResponseEntity(advertise, HttpStatus.OK);
			}
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
	
	}
	
	@DeleteMapping(value ="/user/advertise/{postId}")
	@ApiOperation(value="delete advertise by Id" , notes="This service delete advertise by Id")
	public ResponseEntity<Boolean> deleteAdvertisementById(@RequestHeader("auth-token") String authToken , @PathVariable("id") int postId) {
	boolean result= advertiseService.deleteAdvertisementById(authToken, postId);
	return new ResponseEntity(result,HttpStatus.OK);
	}
	
	
	@GetMapping(value ="/advertise/search/{filtercriteria}", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="filter advertise" , notes="This service fetches advertise based on filter")
	public ResponseEntity<List<Advertise>> getUserAdvertisementByFilter(@PathVariable("filtercriteria") String criteria) {
	
		List<Advertise> advertiseList=new ArrayList<>();
//		Advertise advertise = new Advertise(1, "Laptop", 4000.00, "electronics", "test", new Date(), new Date(), "Closed");
//		advertiseList.add(advertise);
		advertiseList = advertiseService.getUserAdvertisementByFilter(criteria);
			return new ResponseEntity(advertiseList, HttpStatus.OK);
	}
	
	@GetMapping(value ="/advertise/search/{searchText}", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="search advertise" , notes="This service fetches advertise by search")
	public ResponseEntity<List<Advertise>> getUserAdvertisementBySearchtext(@PathVariable("searchText") String searchText) {
	
		List<Advertise> advertiseList=new ArrayList<>();
		/*Advertise advertise = new Advertise(1, "Laptop", 4000.00, "electronics", "test", new Date(), new Date(), "Closed");
		advertiseList.add(advertise);*/
		advertiseList = advertiseService.getUserAdvertisementBySearchtext(searchText);
			return new ResponseEntity(advertiseList, HttpStatus.OK);
			
	}
	
	@GetMapping(value ="/advertise/{postId}", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="advertise by Id" , notes="This service fetches advertise by Id")
	public ResponseEntity<Advertise> getAdvertisementById(@RequestHeader("auth-token") String authToken , @PathVariable("id") int postId) {
	
		if(authToken.equalsIgnoreCase("Mb50026")) {
			//Advertise advertise = new Advertise(1, "Laptop", 4000.00, "electronics", "test", new Date(), new Date(), "Closed");
			Advertise advertise = advertiseService.getAdvertisementById(authToken, postId);
			
			return new ResponseEntity(advertise, HttpStatus.OK);
			}
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}
	
}
