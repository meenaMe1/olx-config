package com.olx.advertise.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.olx.advertise.dto.Advertise;
import com.olx.advertise.entity.AdvertiseEntity;
import com.olx.advertise.repo.OlxAdvertiseRepo;
import com.olx.advertise.service.AdvertiseService;

@Service
public class AdvertiseServiceImpl implements AdvertiseService {

	@Autowired
	Advertise advertise;
	
	@Autowired
	OlxAdvertiseRepo advertiseRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public Advertise createAdvertise(String authToken, Advertise reqAdvertise) {
		AdvertiseEntity advertiseEntity = new AdvertiseEntity(reqAdvertise.getId(), reqAdvertise.getTitle(),reqAdvertise.getPrice(), reqAdvertise.getCategory(), reqAdvertise.getDescription(), reqAdvertise.getCreatedDate(), reqAdvertise.getModifiedDate(), reqAdvertise.getStatus());
				advertiseEntity = advertiseRepo.save(advertiseEntity);
		Advertise advertise =new Advertise(advertiseEntity.getId(), advertiseEntity.getTitle(),advertiseEntity.getPrice(), advertiseEntity.getCategory(), advertiseEntity.getDescription(), advertiseEntity.getCreatedDate(), advertiseEntity.getModifiedDate(), advertiseEntity.getStatus());
		return advertise;
		
	}

	@Override
	public Advertise updateAvertisement(String authToken, Advertise advertise) {
		AdvertiseEntity advertiseEntity = new AdvertiseEntity(advertise.getId(), advertise.getTitle(),advertise.getPrice(), advertise.getCategory(), advertise.getDescription(), advertise.getCreatedDate(), advertise.getModifiedDate(), advertise.getStatus());
		advertiseEntity = advertiseRepo.save(advertiseEntity);
		advertise =new Advertise(advertiseEntity.getId(), advertiseEntity.getTitle(),advertiseEntity.getPrice(), advertiseEntity.getCategory(), advertiseEntity.getDescription(), advertiseEntity.getCreatedDate(), advertiseEntity.getModifiedDate(), advertiseEntity.getStatus());
		return advertise;
	}

	@Override
	public List<Advertise> getAllUserAdvertisement(String authToken) {
		List<AdvertiseEntity> advertiseEntityList= advertiseRepo.findAll();
		List<Advertise> advertiseList = new ArrayList<>();
		for(AdvertiseEntity advertiseEntity :advertiseEntityList) {
			Advertise advertise =new Advertise(advertiseEntity.getId(), advertiseEntity.getTitle(),advertiseEntity.getPrice(), advertiseEntity.getCategory(), advertiseEntity.getDescription(), advertiseEntity.getCreatedDate(), advertiseEntity.getModifiedDate(), advertiseEntity.getStatus());
			advertiseList.add(advertise);
		}
		return advertiseList;
	}

	@Override
	public Advertise getUserAdvertisementById(String authToken, int postId) {
		List<AdvertiseEntity> advertiseEntityList= advertiseRepo.findAll();
		Advertise advertise=null;
		for(AdvertiseEntity advertiseEntity :advertiseEntityList) {
		 advertise =new Advertise(advertiseEntity.getId(), advertiseEntity.getTitle(),advertiseEntity.getPrice(), advertiseEntity.getCategory(), advertiseEntity.getDescription(), advertiseEntity.getCreatedDate(), advertiseEntity.getModifiedDate(), advertiseEntity.getStatus());
			
		}
		return advertise;
	}

	@Override
	public boolean deleteAdvertisementById(String authToken, int postId) {
		if(advertiseRepo.existsById(postId)) {
			advertiseRepo.deleteById(postId);
			return true;
		}
			return false;
		}
	

	@Override
	public List<Advertise> getUserAdvertisementBySearchtext(String searchText) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Advertise getAdvertisementById(String authToken, int postId) {
		List<AdvertiseEntity> advertiseEntityList= advertiseRepo.findAll();
		Advertise advertise=null;
		for(AdvertiseEntity advertiseEntity :advertiseEntityList) {
		 advertise =new Advertise(advertiseEntity.getId(), advertiseEntity.getTitle(),advertiseEntity.getPrice(), advertiseEntity.getCategory(), advertiseEntity.getDescription(), advertiseEntity.getCreatedDate(), advertiseEntity.getModifiedDate(), advertiseEntity.getStatus());
			
		}
		return advertise;
	}

	@Override
	public List<Advertise> getUserAdvertisementByFilter(String criteria) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*
	 * @Bean
	 * 
	 * @LoadBalanced public RestTemplate getRestTemplate() { return new
	 * RestTemplate(); }
	 * 
	 * @Override public boolean isLoggedInUser(String authToken) { HttpHeaders
	 * headers = new HttpHeaders(); headers.set("Authorization", authToken);
	 * HttpEntity entity = new HttpEntity(headers); try { ResponseEntity<Boolean>
	 * response = this.restTemplate.exchange("http://auth-service/token/validate",
	 * HttpMethod.GET, entity, Boolean.class); if(response.getStatusCode() ==
	 * HttpStatus.OK) return response.getBody(); else return false; }
	 * catch(Exception e) { return false; } }
	 */
	

}
