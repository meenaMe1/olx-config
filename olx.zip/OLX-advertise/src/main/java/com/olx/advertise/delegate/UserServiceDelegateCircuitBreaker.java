package com.olx.advertise.delegate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class UserServiceDelegateCircuitBreaker implements UserServiceDelegate, UserDetailsService{
	
	@Autowired
	CircuitBreakerFactory circuitBreakerFactory;

	
	@Autowired
	RestTemplate restTemplate;
	
	@Bean
	@LoadBalanced
	public RestTemplate getRestTemplate() {
	return new RestTemplate();
	}
	
//	@Override
//	public boolean isLoggedInUser(String authToken) {
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("Authorization", authToken);
//		HttpEntity entity = new HttpEntity(headers);
//	CircuitBreaker circuitBreaker= circuitBreakerFactory.create("AUTH_TOKEN_VALIDATION");
//	ResponseEntity<Boolean> result=circuitBreaker.run(
//			() ->this.restTemplate.exchange("http://auth-service/token/validate", HttpMethod.GET, entity, Boolean.class),
//			throwable ->  fallbackForIsLoggedInUser(authToken,throwable)
//			);
//		return false;
//	}
//	
	
	@Override
	@CircuitBreaker(name="AUTH_TOKEN_VALIDATION", fallbackMethod = "fallbackForIsLoggedInUser")
	public boolean isLoggedInUser(String authToken) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", authToken);
		HttpEntity entity = new HttpEntity(headers);
	
	ResponseEntity<Boolean> result=
		this.restTemplate.exchange("http://auth-service/token/validate", HttpMethod.GET, entity, Boolean.class);
		return false;
	}
	public boolean fallbackForIsLoggedInUser(String authToken, Throwable throwable) {
		System.out.println("Login service failed "+throwable);
		return false;
		
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
	

}
