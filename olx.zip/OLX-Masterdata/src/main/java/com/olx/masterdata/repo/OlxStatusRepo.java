package com.olx.masterdata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olx.masterdata.entity.StatusEntity;

public interface OlxStatusRepo  extends JpaRepository<StatusEntity, Integer>{

}
