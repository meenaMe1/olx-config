package com.olx.materdata.service;

import java.util.List;

import com.olx.masterdata.dto.Category;
import com.olx.masterdata.dto.Status;

public interface MasterDataService {
	
	public List<Category> getAllAdvertiseCategory();
	
	public List<Status> getAllAdvertiseStatus();

}
