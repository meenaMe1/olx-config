package com.olx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.olx.dto.AuthenticationRequest;
import com.olx.dto.User;
import com.olx.service.UserService;
import com.olx.utils.JwtUtils;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin(origins="*")
public class UserController {
	
	@Autowired
	UserService userService;
	
	
	@Autowired
	AuthenticationManager authenticateManager;
	
	@Autowired
	JwtUtils jwtUtil;

	
	@GetMapping(value="/token/validate")
	public ResponseEntity<Boolean> isTokenValid(@RequestHeader("Authorization") String jwtToken) {
	
		jwtToken=jwtToken.substring(6, jwtToken.length()).toString().trim();
		System.out.println(jwtToken);
		String userName=jwtUtil.extractUsername(jwtToken);
		System.out.println(userName);
		UserDetails userDetails =userService.loadUserByUsername(userName);
		boolean  validateToken=	jwtUtil.validateToken(jwtToken, userDetails);
		if(validateToken)
		return new ResponseEntity<Boolean>(validateToken,HttpStatus.OK);
		else
		return new ResponseEntity<Boolean>(validateToken,HttpStatus.BAD_REQUEST);	
	}
	
	
	@PostMapping(value="/aunthenticate", consumes=MediaType.APPLICATION_JSON_VALUE)
	 public ResponseEntity<String> authenticate (@RequestBody AuthenticationRequest authenticate){
		 try {
			 
			 authenticateManager.authenticate(new UsernamePasswordAuthenticationToken(authenticate.getUserName(), authenticate.getPassword())); 
		 }catch(Exception e) {
			 e.printStackTrace();
			throw new BadCredentialsException(authenticate.getUserName());
		 }
		 String jwtToken = jwtUtil.generateToken(authenticate.getUserName());
		return new ResponseEntity<String>(jwtToken,HttpStatus.OK);
		 
	 } 
	@PostMapping(value ="/user/authenticate", consumes={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="auntenticate user" , notes="This service aunthenticate a user")
	public ResponseEntity<String> authenticateUser(@RequestBody User login) {
		
		String authToken=userService.authenticateUser(login);
		System.out.println(authToken);
	return new ResponseEntity(authToken,HttpStatus.OK);
	}
	
	
	
	@PostMapping(value ="/user", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="register user" , notes="This service register a user")
	public ResponseEntity<User> getUserRegistration(@RequestBody User login) {
		User user= userService.getUserRegistration(login);
	return new ResponseEntity(login,HttpStatus.OK);
	}
	
	@DeleteMapping(value ="/user/logout", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="logout user" , notes="This service logout a user")
	public ResponseEntity<Boolean> userLogout(@RequestHeader("auth-token") String authToken) {
		boolean logout = false;
		if(authToken.equalsIgnoreCase("Mb50026")) {
			logout=	userService.userLogout(authToken);
			return new ResponseEntity(logout, HttpStatus.OK);
			}
			return new ResponseEntity(logout,HttpStatus.BAD_REQUEST);
	}
	
	@GetMapping(value ="/user", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="user details" , notes="This service fetches user details")
	public ResponseEntity<User> getUserDetails(@RequestHeader("auth-token") String authToken) {
		if(authToken.equalsIgnoreCase("Mb50026")) {
			User user= userService.getUserDetails(authToken);
			return new ResponseEntity(user, HttpStatus.OK);
			}
			return new ResponseEntity(null,HttpStatus.BAD_REQUEST);
	
	}
}
