package com.zensar.user.services;

import java.util.List;

import com.zensar.user.beans.ResponseDo;
import com.zensar.user.beans.UserDo;

public interface UserServices {

	public ResponseDo getUser(int userId);
	public ResponseDo addUser(int userId,String userName,String userContactNumber,String userEmailId);
	public ResponseDo deleteUser(int userId);
	public ResponseDo updateUser(int userId,String userName,String userContactNumber,String userEmailId);
	
	
}
