package com.zensar.user.dao;

import java.util.List;

import com.zensar.user.beans.ResponseDo;
import com.zensar.user.beans.UserDo;

public interface UserDao {

	public List<UserDo> getUser(int userId);
	public int addUser(int userId,String userName,String userContactNumber,String userEmailId);
	public int deleteUser(int userId);
	public int updateUser(int userId,String userName,String userContactNumber,String userEmailId);
}
