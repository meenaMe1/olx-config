package com.zensar.user.daoImpl;

import java.util.ArrayList;


import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.zensar.user.beans.ResponseDo;
import com.zensar.user.beans.UserDo;
import com.zensar.user.constants.QueryConstants;
import com.zensar.user.dao.UserDao;

@Repository

public class UserDaoImpl implements UserDao {

	private Logger log = LoggerFactory.getLogger(UserDaoImpl.class);

	@Autowired
	private EntityManagerFactory entityManager;

	@Autowired
	private QueryConstants queryConstants;

	
	
	@PersistenceContext(unitName = "MYSQL_DB")
	private EntityManager mySqlSession;

	
	@Override
	public List<UserDo> getUser(int userId) {
		EntityManager session = entityManager.createEntityManager();
		UserDo userDo = null;
		List<UserDo> listUser = new ArrayList();

		try {
			List<Object[]> resultSet = session.createNativeQuery(queryConstants.getGetUsers())
					.setParameter("userId", userId).getResultList();
			for (Object[] result : resultSet) {
				userDo = new UserDo();
				userDo.setUserId((int) result[0]);
				userDo.setUserName(result[1] != null ? ((String) result[1]).trim() : "");
				userDo.setUserContactNumber(result[2] != null ? ((String) result[2]).trim() : "");
				userDo.setUserEmailId(result[3] != null ? ((String) result[3]).trim() : "");
				listUser.add(userDo);
			}

		} catch (NoResultException e) {
			log.error("error in userDetails :" + new Date());
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		return listUser;
	}

	@Override

	public int  addUser(int userId,String userName,String userContactNumber,String userEmailId) {
		EntityManager session = entityManager.createEntityManager();
		EntityTransaction transaction = session.getTransaction();
		transaction.begin();
		Query query=null;
		int resultSet =0;
		try {
			 query = session.createNativeQuery(queryConstants.getInsertUsers())
					.setParameter("userId",userId)
					.setParameter("userName", userName)
					.setParameter("userContactNumber", userContactNumber)
					.setParameter("userEmailId", userEmailId);
				resultSet=query.executeUpdate();
				transaction.commit();
			
					} catch (NoResultException e) {
			log.error("error in addUser :" + new Date());
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		
		return resultSet;
	}

	@Override
	public int deleteUser(int userId) {
		EntityManager session = entityManager.createEntityManager();
		EntityTransaction transaction = session.getTransaction();
		transaction.begin();
		Query query=null;
		int resultSet=0;
		try {
			query = session.createNativeQuery(queryConstants.getDeleteUsers())
					.setParameter("userId", userId);
			resultSet=query.executeUpdate();
			transaction.commit();					
			} catch (NoResultException e) {
			log.error("error in deleteUser :" + new Date());
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		return resultSet;
			}

	@Override
	public int updateUser(int userId,String userName,String userContactNumber,String userEmailId) {
		EntityManager session = entityManager.createEntityManager();
		EntityTransaction transaction = session.getTransaction();
		transaction.begin();
		Query query=null;
		int resultSet=0;
		try {
			query = session.createNativeQuery(queryConstants.getUpdateUsers())
					.setParameter("userId",userId)
					.setParameter("userContactNumber", userContactNumber);
				resultSet=query.executeUpdate();
				transaction.commit();
					} catch (NoResultException e) {
			log.error("error in updateUser :" + new Date());
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		
		return resultSet;
	}

}
