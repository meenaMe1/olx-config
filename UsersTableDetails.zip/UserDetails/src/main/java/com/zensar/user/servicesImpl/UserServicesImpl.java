package com.zensar.user.servicesImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.user.beans.ResponseDo;
import com.zensar.user.beans.Status;
import com.zensar.user.beans.UserDo;
import com.zensar.user.dao.UserDao;
import com.zensar.user.services.UserServices;

@Service
public class UserServicesImpl implements UserServices {

private Logger log=LoggerFactory.getLogger(UserServicesImpl.class);
	
	@Autowired
	UserDao userDao;
	
	@Override
	public ResponseDo getUser(int userId) {
		log.info("Start of userDetails :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		Status status= new Status();
		try {
		List<UserDo> userList=userDao.getUser(userId);
		
		if(userList!=null) {
			status.setStatusCode(1);
			status.setStatusMessage("User Details Retrived Succesfully");
		}
		else {
			status.setStatusCode(0);
			status.setStatusMessage("Particular User Details are not Retrived");
		}
		 responseDo.setDetails(userList);
		 responseDo.setStatus(status);
		 return responseDo;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			log.error("error in userDetails :"+e.getStackTrace());
			return null;
		}
	}

	@Override
	public ResponseDo addUser(int userId,String userName,String userContactNumber,String userEmailId) {
		log.info("Start of addUser :"+new Date());	
		ResponseDo responseDo=new ResponseDo();
		Status status= new Status();
		try {
			int addUsers=userDao.addUser(userId,userName,userContactNumber,userEmailId);
		
		if(addUsers!=0) {
			status.setStatusCode(1);
			status.setStatusMessage("User added Successfully");
		}
		else {
			status.setStatusCode(0);
			status.setStatusMessage("User not added");
		}
		  responseDo.setDetails(addUsers);
		  responseDo.setStatus(status);
		 return responseDo;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			log.error("error in addUser :"+e.getMessage());
			return null;
		}
	}

	@Override
	public ResponseDo deleteUser(int userId) {
		log.info("Start of deleteUser :"+new Date());	
		ResponseDo responseDo=new ResponseDo();
		Status status= new Status();
		try {
		int deleteUser=userDao.deleteUser(userId);
		
		if(deleteUser!=0) {
			status.setStatusCode(1);
			status.setStatusMessage("User deleted Successfully");
		}
		else {
			status.setStatusCode(0);
			status.setStatusMessage("User not deleted");
		}
		 responseDo.setDetails(deleteUser);
		 responseDo.setStatus(status);
		 return responseDo;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			log.error("error in deleteUser :"+e.getStackTrace());
			return null;
		}
	}

	@Override
	public ResponseDo updateUser(int userId,String userName,String userContactNumber,String userEmailId) {
		log.info("Start of updateUser :"+new Date());	
		ResponseDo responseDo=new ResponseDo();
		Status status= new Status();
		try {
		int updateUsers=userDao.updateUser(userId,userName,userContactNumber,userEmailId);
		
		if(updateUsers!=0) {
			status.setStatusCode(1);
			status.setStatusMessage("User updated Successfully");
		}
		else {
			status.setStatusCode(0);
			status.setStatusMessage("User not updated");
		}
		 responseDo.setDetails(updateUsers);
		 responseDo.setStatus(status);
		 return responseDo;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			log.error("error in updateUser :"+e.getStackTrace());
			return null;
		}
	}
	
}
