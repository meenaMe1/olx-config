package com.zensar.user.beans;

import org.springframework.stereotype.Component;

@Component
public class UserDo {

	private int userId;
	private String userName;
	private String userContactNumber;
	private String userEmailId;
	
	public UserDo() {
		super();
	}

	public UserDo(int userId, String userName, String userContactNumber, String userEmailId) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userContactNumber = userContactNumber;
		this.userEmailId = userEmailId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserContactNumber() {
		return userContactNumber;
	}

	public void setUserContactNumber(String userContactNumber) {
		this.userContactNumber = userContactNumber;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	@Override
	public String toString() {
		return "UserDo [userId=" + userId + ", userName=" + userName + ", userContactNumber=" + userContactNumber
				+ ", userEmailId=" + userEmailId + "]";
	}
	
	
	}
