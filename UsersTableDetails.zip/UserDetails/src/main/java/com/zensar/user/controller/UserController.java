package com.zensar.user.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.user.beans.RequestBodyDo;
import com.zensar.user.beans.ResponseDo;
import com.zensar.user.beans.UserDo;
import com.zensar.user.services.UserServices;

@RestController
public class UserController {
	private Logger log=LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserServices userServices;
	
	@GetMapping("/getUser")
	public ResponseDo getUser(@RequestBody RequestBodyDo requestBodyDo) {
		log.info("Start of getUser :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		int userId=requestBodyDo.getUserId();
		try {
		responseDo=userServices.getUser(userId);
		}
		catch (Exception e) {
			log.error("error in getUserDetails :"+e.getStackTrace());
		}
		return responseDo;	
	}
	
	@PostMapping("/addUsers")
	public ResponseDo addUsers(@RequestBody RequestBodyDo requestBodyDo) {
		log.info("Start of addUsers :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		int userId=requestBodyDo.getUserId();
		String userName=requestBodyDo.getUserName();
		String userContactNumber=requestBodyDo.getUserContactNumber();
		String userEmailId=requestBodyDo.getUserEmailId();
		try {
		responseDo=userServices.addUser(userId,userName,userContactNumber,userEmailId);
		}
		catch (Exception e) {
			log.error("error in addUsers :"+e.getMessage());
		}
		return responseDo;	
	}
	
	@PutMapping("/updateUsers")
	public ResponseDo updateUsers(@RequestBody RequestBodyDo requestBodyDo ) {
		log.info("Start of addUsers :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		int userId=requestBodyDo.getUserId();
		String userName=requestBodyDo.getUserName();
		String userContactNumber=requestBodyDo.getUserContactNumber();
		String userEmailId=requestBodyDo.getUserEmailId();
		try {
		responseDo=userServices.updateUser(userId,userName,userContactNumber,userEmailId);
		}
		catch (Exception e) {
			log.error("error in updateUsers :"+e.getStackTrace());
		}
		return responseDo;	
	}

	@DeleteMapping("/deleteUsers")
	public ResponseDo deleteUsers(@RequestBody RequestBodyDo requestBodyDo) {
		log.info("Start of addUsers :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		int userId=requestBodyDo.getUserId();
		try {
		responseDo=userServices.deleteUser(userId);
		}
		catch (Exception e) {
			log.error("error in deleteUsers :"+e.getStackTrace());
		}
		return responseDo;	
	}

}
