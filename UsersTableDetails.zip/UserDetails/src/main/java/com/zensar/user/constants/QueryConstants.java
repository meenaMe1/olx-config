package com.zensar.user.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value="classpath:queries.properties")

public class QueryConstants {

	@Value("${insertUsers}")
	public String insertUsers;
	
	@Value("${updateUsers}")
	public String updateUsers;
	
	@Value("${getUsers}")
	public String getUsers;
	
	@Value("${deleteUsers}")
	public String deleteUsers;

	public String getInsertUsers() {
		return insertUsers;
	}

	public void setInsertUsers(String insertUsers) {
		this.insertUsers =insertUsers;
	}

	public String getUpdateUsers() {
		return updateUsers;
	}

	public void setUpdateUsers(String updateUsers) {
		this.updateUsers = updateUsers;
	}

	public String getGetUsers() {
		return getUsers;
	}

	public void setGetUsers(String getUsers) {
		this.getUsers = getUsers;
	}

	public String getDeleteUsers() {
		return deleteUsers;
	}

	public void setDeleteUsers(String deleteUsers) {
		this.deleteUsers = deleteUsers;
	}
	
}
