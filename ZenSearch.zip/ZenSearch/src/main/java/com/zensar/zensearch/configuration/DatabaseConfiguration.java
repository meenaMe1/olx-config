package com.zensar.zensearch.configuration;

import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class DatabaseConfiguration {

	private Logger log=LoggerFactory.getLogger(DatabaseConfiguration.class);
	
	@Primary
	@Bean
	public JpaVendorAdapter getJpaVendorAdapter() {
		JpaVendorAdapter adapter=new HibernateJpaVendorAdapter();
		return adapter;
	}
	
	@Bean(name = "mysqlDb")
	@ConfigurationProperties(prefix = "spring.mysql")
	public DataSource mysqlDataSource() {
		log.info("****** connection created successfully *******");
		return DataSourceBuilder.create().build();
	}
	
	
	@Bean(name = "mysqljpa")
	public LocalContainerEntityManagerFactoryBean mySqlEntityManagerFactory(@Qualifier("mysqlDb") DataSource dataSource) {
		
        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setDataSource(dataSource);
        entityManagerFactoryBean.setJpaVendorAdapter(getJpaVendorAdapter());
        entityManagerFactoryBean.setPersistenceUnitName("MYSQL_DB");
        entityManagerFactoryBean.setPackagesToScan("com.zensar.zenhelp");
        entityManagerFactoryBean.setJpaProperties(mySqlJpaProperties());

		return entityManagerFactoryBean;
	}
	private Properties mySqlJpaProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        return properties;        
}	
	
	@Bean(name = "defaultTransactionManager")
    public PlatformTransactionManager defaultTransactionManager() {
		 JpaTransactionManager transactionManager
         = new JpaTransactionManager();
       transactionManager.setEntityManagerFactory(
       		mySqlEntityManagerFactory(null).getObject());
       return transactionManager;
    }

}

