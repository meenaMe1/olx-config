package com.zensar.zensearch.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.zensearch.beans.UserInfo;
import com.zensar.zensearch.repository.SearchRepository;
import com.zensar.zensearch.service.SearchService;

@Service
public class ServiceImpl implements SearchService{

	@Autowired
	private SearchRepository repo;
	
	@Override
	public List<UserInfo> getUserInfo(String searchText) {
		return repo.getUserInfo(searchText);
	}

}
