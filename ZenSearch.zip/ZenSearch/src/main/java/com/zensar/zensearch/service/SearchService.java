package com.zensar.zensearch.service;

import java.util.List;

import com.zensar.zensearch.beans.UserInfo;


public interface SearchService {

	List<UserInfo> getUserInfo(String searchText);

	
}
