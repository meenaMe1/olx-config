package com.zensar.zensearch.repository;

import java.util.List;

import com.zensar.zensearch.beans.UserInfo;

public interface SearchRepository {

	List<UserInfo> getUserInfo(String searchText);

	
}
