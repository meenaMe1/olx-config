package com.zensar.zensearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZenSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZenSearchApplication.class, args);
	}

}
