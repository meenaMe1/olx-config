package com.zensar.zensearch.constants;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.zensar.zensearch.beans.UserInfo;

@Component
@PropertySource({"classpath:exit-zentalent-queries.properties"})
@ConfigurationProperties
public class QueryConstant {

	private String userInfo;

	public String getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(String userInfo) {
		this.userInfo = userInfo;
	}
	
	
	
}
