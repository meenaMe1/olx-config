package com.zensar.zensearch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zensearch.beans.UserInfo;
import com.zensar.zensearch.service.SearchService;

@RestController
@RequestMapping("/zenSearch")
public class SearchController {

	@Autowired
	private SearchService service;
	
	@GetMapping("/search/{searchText}")
	public List<UserInfo> getUserInfo(@PathVariable("searchText") String searchText) {
		return service.getUserInfo(searchText);
	}
}
