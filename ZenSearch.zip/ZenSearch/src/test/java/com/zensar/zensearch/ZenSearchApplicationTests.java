package com.zensar.zensearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZenSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
