package com.zensar.zentalent;

import java.time.LocalDateTime;

public class FinancialYear {

	public static void main(String[] args) {
		LocalDateTime date = LocalDateTime.now();
		if(date.getMonth().getValue()<=3) {
			System.out.println("Financial Year is : "+(date.getYear()-1)+" - "+date.getYear());
		}
		else {
			System.out.println("Financial Year is : "+date.getYear()+" - "+(date.getYear()+1));
		}
	}

}
