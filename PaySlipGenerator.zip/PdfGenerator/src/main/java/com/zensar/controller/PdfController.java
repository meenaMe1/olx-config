package com.zensar.controller;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PdfController {

	@PostMapping("/generate")
	public String generatePdf() throws IOException {
		String path = "D:\\TazWorkspace\\PdfGenerator\\Sample.pdf";
		PDFont font = PDType1Font.TIMES_ROMAN;
		PDFont fontBold = PDType1Font.TIMES_BOLD;
		float fontSize = 14;
		float fontHeight = fontSize;
		float leading = 20;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd");
		Date date = new Date();
		// "Date Generated: " + dateFormat.format(date)

		PDDocument doc = new PDDocument();
		PDPage page = new PDPage();
		doc.addPage(page);

		PDPageContentStream contentStream = new PDPageContentStream(doc, page);
		contentStream.setFont(font, 10);

		float yCordinate = page.getCropBox().getUpperRightY() - 30;
		float startX = page.getCropBox().getLowerLeftX() + 30;
		float endX = page.getCropBox().getUpperRightX() - 30;

		PDImageXObject pdImage = PDImageXObject.createFromFile("C:\\Users\\sp61808\\Desktop\\zensar.JPG", doc);
		contentStream.drawImage(pdImage, startX, 700, 120, 80);

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 380, yCordinate - 15);
		contentStream.showText("ZENSAR TECHNOLOGIES LIMITED");
		yCordinate -= fontHeight; // This line is to track the yCordinate
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.setFont(font, 8);
		contentStream.showText("Zensar Knowledge Park, Kharadi, Pune-411014");
		yCordinate -= fontHeight;

		/*
		 * contentStream.newLineAtOffset(0, -leading + 10); yCordinate -= leading;
		 * contentStream.setFont(font, 8);
		 * contentStream.showText("Plot # 4, MIDC, Off Nagar Road, Pune-411014");
		 * yCordinate -= fontHeight;
		 */

		contentStream.endText(); // End of text mode

		/*
		 * contentStream.moveTo(startX, yCordinate); contentStream.lineTo(endX,
		 * yCordinate); contentStream.stroke(); yCordinate -= leading;
		 */

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 220, yCordinate - 10);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Payslip for the month of Sept-2021");
		contentStream.endText();

		contentStream.moveTo(startX, yCordinate - 12);
		contentStream.lineTo(endX, yCordinate - 12);
		contentStream.stroke();
		yCordinate -= leading;

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Emp No.");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("Emp Name");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("Designation");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("Bank Name");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("Bank Account No.");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 112, yCordinate + 80);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 402, yCordinate + 160);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Attendance");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("Joining Date");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("PAN");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("PF No.");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("UAN No.");
		contentStream.endText();
		
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 477, yCordinate + 240);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.newLineAtOffset(0, -leading + 10);
		yCordinate -= leading;
		contentStream.showText("XXXXX");
		contentStream.endText();
		

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 645, 551, 70);
		contentStream.stroke();

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 645, 110, 57);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(430, 645, 75, 57);
		contentStream.stroke();

		contentStream.setNonStrokingColor(Color.LIGHT_GRAY);
		contentStream.addRect(30, 605, 551, 40);
		contentStream.fill();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(250, 605, 331, 19);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 605, 551, 40);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(250, 219, 180, 426);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(350, 219, 155, 405);
		contentStream.stroke();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate + 250);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Head");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 280, yCordinate + 257);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Current Month");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 450, yCordinate + 257);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("April To Date");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 288, yCordinate + 237);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Earning");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 360, yCordinate + 237);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Deduction");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 443, yCordinate + 237);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Earning");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 512, yCordinate + 237);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Deduction");
		contentStream.endText();

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 45, 551, 560);
		contentStream.stroke();

		contentStream.moveTo(startX, yCordinate - 155);
		contentStream.lineTo(endX, yCordinate - 155);
		contentStream.stroke();
		yCordinate -= leading;

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 185, 551, 45);
		contentStream.stroke();

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 163, 551, 12);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 140, 551, 12);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 117, 551, 12);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 94, 551, 12);
		contentStream.stroke();

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(30, 45, 551, 40);
		contentStream.stroke();

		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(120, 85, 130, 100);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(250, 85, 100, 100);
		contentStream.stroke();
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.addRect(428, 85, 77, 90);
		contentStream.stroke();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate + 240);
		contentStream.setFont(font, 8);
		contentStream.showText("Basic");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("Consolidated Allowance");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("Statutory Bonus");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("Internet Reimbursement");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("Provident Fund");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("Profession Tax");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 285, yCordinate + 340);
		contentStream.setFont(font, 8);
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 440, yCordinate + 400);
		contentStream.setFont(font, 8);
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 365, yCordinate + 410);
		contentStream.setFont(font, 8);
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 517, yCordinate + 430);
		contentStream.setFont(font, 8);
		contentStream.showText("0000.00");
		contentStream.newLineAtOffset(0, -leading + 8);
		yCordinate -= leading;
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate + 128);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Total:-");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 285, yCordinate + 128);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 365, yCordinate + 128);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 440, yCordinate + 128);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 516, yCordinate + 128);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("0000.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate + 95);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Net Salary : Rs. 0000.00 (Rs. Zero Only)");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 235, yCordinate + 82);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Reimbursement Balance");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 303, yCordinate + 60);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("LTA");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 377, yCordinate + 60);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("00.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate + 48);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Telephone Bill Needed");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 198, yCordinate + 48);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("00.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate + 25);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("Petrol Bill Needed");
		contentStream.endText();
		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 198, yCordinate + 25);
		contentStream.setFont(fontBold, 8);
		contentStream.showText("00.00");
		contentStream.endText();

		contentStream.beginText();
		contentStream.newLineAtOffset(startX + 2, yCordinate - 30);
		contentStream.setFont(fontBold, 8);
		contentStream.showText(
				"Message : * Please check your PAN if any correction need in PAN. Please write to Zensar.Payroll@Paysquare.com for any query. *");
		contentStream.endText();
		/*
		 * Bold + thin Line contentStream.setLineWidth(1); contentStream.addLine(200,
		 * 250, 400, 250); contentStream.closeAndStroke();
		 * contentStream.setLineWidth(5); contentStream.addLine(200, 300, 400, 300);
		 * contentStream.closeAndStroke();
		 */

		/*
		 * contentStream.setFont( font, 12 ); contentStream.moveTextPositionByAmount(
		 * 400, 700 ); contentStream.drawString( "ZENSAR TECHNOLOGIES LIMITED" );
		 * contentStream.newLineAtOffset(0, -20); //contentStream.setFont( font, 10 );
		 * //contentStream.drawString( "Zensar Knowledge Park, Kharadi" );
		 * //contentStream.drawString( "Plot #4, MIDC, Off Nagar Road, Pune-411014" );
		 * contentStream.endText();
		 */
		contentStream.close();
		doc.save(path);
		System.out.println("PDF created");
		doc.close();
		return "Pdf created successfully at : " + path;
	}
}
