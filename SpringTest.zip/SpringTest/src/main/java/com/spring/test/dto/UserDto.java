package com.spring.test.dto;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
@Component
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
	
	
	private String userName;
	
	private String password;
	
	private String role;

}
