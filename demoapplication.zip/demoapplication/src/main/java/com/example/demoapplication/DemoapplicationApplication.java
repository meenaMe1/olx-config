package com.example.demoapplication;

import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@SpringBootApplication
@EnableScheduling
public class DemoapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoapplicationApplication.class, args);
	}
	
	@Scheduled(fixedDelayString = "PT1M")
	void jobSch() throws InterruptedException {
		System.out.println("Now is jobSch " + new Date()); 
		//Thread.sleep(5000L);
	}
	 
	

}
