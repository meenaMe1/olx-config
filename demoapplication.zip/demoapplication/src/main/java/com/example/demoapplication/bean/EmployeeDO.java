package com.example.demoapplication.bean;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;


@SqlResultSetMapping(name = "user_mapping",classes = {
		@ConstructorResult( targetClass = EmployeeDO.class, 
				columns = { 
						@ColumnResult(name = "Employee_Number",type = String.class),
						@ColumnResult(name = "Employee_Name", type = String.class),
						@ColumnResult(name = "first_Name", type = String.class),
						@ColumnResult(name = "last_name", type = String.class),
						@ColumnResult(name = "MIDDLE_NAMES", type =String.class),
						@ColumnResult(name = "GRADE", type = String.class),
						@ColumnResult(name = "DESIGNATION", type=String.class),
						@ColumnResult(name = "EMAIL_ID", type=String.class)
						}),
		}
)
@Entity
@Table(name = "ZEN.XXG4_ZENHELP_ASSO_USRPROFL_TBL")
public class EmployeeDO
{
	@Id
	private String employeeNumber;
	private String employeeName;
	private String firstName;
	private String lastName;
	private String middleName;
	private String grade;
	private String designation;
	private String emailId;
	
	private String path;
	private String dpath;
	private String oldFolderName;
	private String newFolderName;
	
	private String imageName;
	//private List employeeList;
	
	// private MultipartStream data;
	 

	public EmployeeDO() {
		super();
	}

	public EmployeeDO(String employeeNumber, String employeeName, String firstName, String lastName, String middleName,
			String grade, String designation, String emailId) {
		
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.grade = grade;
		this.designation = designation;
		this.emailId = emailId;
	}

	
	/*
	 * public List<String> getEmployeeList() { return employeeList; }
	 * 
	 * public void setEmployeeList(List<String> employeeList) { this.employeeList =
	 * employeeList; }
	 */
	
	public String getEmployeeNumber() {
		return employeeNumber;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getDpath() {
		return dpath;
	}

	public void setDpath(String dpath) {
		this.dpath = dpath;
	}

	public String getOldFolderName() {
		return oldFolderName;
	}

	public void setOldFolderName(String oldFolderName) {
		this.oldFolderName = oldFolderName;
	}

	public String getNewFolderName() {
		return newFolderName;
	}

	public void setNewFolderName(String newFolderName) {
		this.newFolderName = newFolderName;
	}

	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	@Override
	public String toString() {
		return "EmployeeDO [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", firstName="
				+ firstName + ", lastName=" + lastName + ", middleName=" + middleName + ", grade=" + grade
				+ ", designation=" + designation + ", emailId=" + emailId + ", path=" + path + "]";
	}
	
	
}
