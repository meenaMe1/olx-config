package com.example.demoapplication.constant;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;


@Component
@PropertySource({"classpath:queries.properties"})
@ConfigurationProperties
public class QueryConstants {

	private String employee_details;
	private String associate_details;

	public String getEmployee_details() {
		return employee_details;
	}

	public void setEmployee_details(String employee_details) {
		this.employee_details = employee_details;
	}

	public String getAssociate_details() {
		return associate_details;
	}

	public void setAssociate_details(String associate_details) {
		this.associate_details = associate_details;
	}
	
	
	
}
