package com.example.demoapplication.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class DataSourceCheck{
	
	@PersistenceContext(unitName = "employee_DB")
	EntityManager em;
	
	@PersistenceContext(unitName = "banking_DB")
	EntityManager userEM;
	
	@Transactional(transactionManager = "employeeTransactionManager")
	public Integer checkUserId()
	{
		Query q = em.createNativeQuery("update accountopening set userId=123 where userId=101");
		Integer result = q.executeUpdate();
		
		return result;
	}
	
	@Transactional(transactionManager = "userTransactionManager")
	public Integer setOtp()
	{
		Query q = userEM.createNativeQuery("select count(*) from opentheaccount where userId=1006");
		//sInteger result = q.executeUpdate();
		
		Integer result=((Number) q.getSingleResult()).intValue();
		
		return result;
	}
	
}
