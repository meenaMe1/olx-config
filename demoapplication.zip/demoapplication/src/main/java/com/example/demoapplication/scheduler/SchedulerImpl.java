/*
 * package com.example.demoapplication.scheduler;
 * 
 * import java.text.SimpleDateFormat; import java.util.Date;
 * 
 * import org.apache.commons.logging.Log; import
 * org.apache.commons.logging.LogFactory; import
 * org.springframework.scheduling.annotation.Scheduled; import
 * org.springframework.stereotype.Component;
 * 
 * import com.example.demoapplication.DemoapplicationApplication;
 * 
 * @Component public class SchedulerImpl {
 * 
 * Log logger = LogFactory.getLog(SchedulerImpl.class);
 * 
 * //@Scheduled(fixedRate = 50000L)
 * 
 * @Scheduled(cron = "30 44 17/8 * * FRI") public void cronJobSch() {
 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); Date
 * now = new Date(); String strDate = sdf.format(now);
 * //logger.info("Java cron job expression:: " + strDate);
 * System.out.println("The cron job is "+strDate); }
 * 
 * 
 * @Scheduled(initialDelay = 5000L,fixedRateString =
 * "${sample.schedule.string}") public void scheduleTaskWithFixedRate() throws
 * InterruptedException { task1(); task2(); }
 * 
 * public void task1() throws InterruptedException { logger.info("Task 1 starts"
 * + Thread.currentThread()); Thread.sleep(1000); logger.info("Task 1 ends" +
 * Thread.currentThread()); }
 * 
 * public void task2() throws InterruptedException { logger.info("Task 2 starts"
 * + Thread.currentThread()); Thread.sleep(1000); logger.info("Task 2 ends" +
 * Thread.currentThread()); } }
 */