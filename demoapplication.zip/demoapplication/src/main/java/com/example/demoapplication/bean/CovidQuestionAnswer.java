package com.example.demoapplication.bean;

import java.util.List;

public class CovidQuestionAnswer {
	
	private Integer questionId;
	private String answerId;
	private String questionText;
	private String icon;
	private List<String> questionBullets;
	private List<AnswerList> answerList;
	
	
	public CovidQuestionAnswer() {
		super();
	}
	public CovidQuestionAnswer(List<AnswerList> answerList)
	{
		this.answerList = answerList;
	}
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public String getQuestionText() {
		return questionText;
	}
	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public List<String> getQuestionBullets() {
		return questionBullets;
	}
	public void setQuestionBullets(List<String> questionBullets) {
		this.questionBullets = questionBullets;
	}
	public List<AnswerList> getAnswerList() {
		return answerList;
	}
	public void setAnswerList(List<AnswerList> answerList) {
		this.answerList = answerList;
	}
	public String getAnswerId() {
		return answerId;
	}
	public void setAnswerId(String answerId) {
		this.answerId = answerId;
	}
	
	
}
