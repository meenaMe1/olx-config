package com.example.demoapplication.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demoapplication.bean.CovidQuestionAnswer;
import com.example.demoapplication.bean.EmployeeDO;
import com.example.demoapplication.bean.UserDetails;
import com.example.demoapplication.constant.QueryConstants;
import com.example.demoapplication.dao.UpdateDAO;

@Repository
public class UpdateDaoImpl implements UpdateDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	@PersistenceContext(unitName = "MYSQL_DB")
	private EntityManager mySqlSession;
	  
	@Autowired
	QueryConstants queryConstants;  

	@Transactional
	public List<Object[]> updateDaoImpl(int newId) {
		
		Query q = mySqlSession.createNativeQuery("update logindetails set password='123' where loginid=1012");

		List<Object[]> list = null; // q.setParameter(1, newId);
		q.executeUpdate();
		/*
		 * try { list = q.getResultList();
		 * 
		 * } catch (Exception e) { System.out.println(e); return list; }finally { if
		 * (mySqlSession.isOpen()) mySqlSession.close(); }
		 */
		return list;

	}
	  
	 
	public List<EmployeeDO[]> getEmpDetails(String id1, String id2) {
		Query q = entityManager.createNativeQuery("select EMPLOYEE_NUMBER, EMPLOYEE_NAME, FIRST_NAME, LAST_NAME, MIDDLE_NAMES, GRADE, DESIGNATION, EMAIL_ID "
				+ "from ZEN.XXG4_ZENHELP_ASSO_USRPROFL_TBL where EMPLOYEE_NUMBER in (:ids1,:ids2)",
				"user_mapping");

		q.setParameter("ids1", id1);
		q.setParameter("ids2", id2);
		
		List<EmployeeDO[]> list = q.getResultList();

		return list;
	}
	
	public List<UserDetails> getHRMSDetails() {
		Query q = mySqlSession.createNativeQuery(queryConstants.getEmployee_details());

		List<Object[]> list = q.getResultList();
		List<UserDetails> userDetailList = null;
		if (list != null) {
			userDetailList = new ArrayList<>();
			
			System.out.println("The size is "+list.size());
			for (Object[] result : list) {
				UserDetails detail = new UserDetails();
				
				detail.setUserId((Integer) result[0]);
				
				//System.out.println("The userId "+(Integer) result[0]);
				detail.setUserName((String) result[1]);
				
				detail.setDesignation((String) result[2]);
				detail.setGrade((String) result[3]);

				detail.setPractice((String) result[4]);
				detail.setSubPractice((String) result[5]);
				
				detail.setManagerId((Integer) result[6]);
				detail.setManagerName((String) result[7]);
				detail.setProfilePicUrl((String) result[8]);
				
				detail.setServiceLine((String) result[9]);
				
				detail.setActiveStatus((Integer) result[10]);
				
				userDetailList.add(detail);
			}
		}

		return userDetailList;
	}
	public Integer checkUserExisted(Integer userId)
	{
		Query q= mySqlSession.createNativeQuery("select count(userId) from UserDetails where userId=:id");
		
		q.setParameter("id", userId);
		
		Integer result = ((Number) q.getSingleResult()).intValue();
		
		return result;
	}
	
	@Transactional(transactionManager = "defaultTransactionManager")
	public Integer insertData(UserDetails userDetails)
	{
		Query q= mySqlSession.createNativeQuery("insert into UserDetails(userId,userName,designation,grade,practice,subPractice,managerId,"
				+ "managerName,profilePicUrl,serviceLine,activeStatus) values(:id,:name,:desg,:grade,:practice,:subpractice,:mgrid,:mgrname,"
				+ ":picurl,:serviceline,:status)");
		
		q.setParameter("id", userDetails.getUserId());
		q.setParameter("name", userDetails.getUserName());
		q.setParameter("desg", userDetails.getDesignation());
		q.setParameter("grade", userDetails.getGrade());
		q.setParameter("practice", userDetails.getPractice());
		q.setParameter("subpractice", userDetails.getSubPractice());
		q.setParameter("mgrid", userDetails.getManagerId());
		q.setParameter("mgrname", userDetails.getManagerName());
		q.setParameter("picurl", userDetails.getProfilePicUrl());
		q.setParameter("serviceline", userDetails.getServiceLine());
		q.setParameter("status", userDetails.getActiveStatus());
		
		Integer result = q.executeUpdate();
		return result;	
	}
	
	@Transactional(transactionManager = "defaultTransactionManager")
	public Integer updateUserData(UserDetails userDetails)
	{
		Query q = mySqlSession.createNativeQuery("update UserDetails set userName=:name,designation=:desg,grade=:grade,practice=:practice,"
				+ "subPractice=:subpra,managerId=:mgrid,managerName=:mgrName,profilePicUrl=:picUrl,serviceLine=:serviceline,activeStatus=:status where userId=:id");
		
		q.setParameter("name", userDetails.getUserName());
		q.setParameter("desg", userDetails.getDesignation());
		q.setParameter("grade", userDetails.getGrade());
		q.setParameter("practice", userDetails.getPractice());
		q.setParameter("subpra", userDetails.getSubPractice());
		q.setParameter("mgrid", userDetails.getManagerId());
		q.setParameter("mgrName", userDetails.getManagerName());
		q.setParameter("picUrl", userDetails.getProfilePicUrl());
		q.setParameter("serviceline", userDetails.getServiceLine());
		q.setParameter("status", userDetails.getActiveStatus());
		
		q.setParameter("id", userDetails.getUserId());
		
		Integer result = q.executeUpdate();
		return result;
	}
	
	public List<Object[]> qntAnswer()	
	{
		Query q = mySqlSession.createNativeQuery("SELECT question.id,question.questionText,question.icon,answer.id as ansId,answer.answerText "
				+ "FROM covidQuestion question JOIN covidQAMapping answer "
				+ "ON question.id = answer.questionId WHERE question.active=1");
		
		List<Object[]> list = q.getResultList();
		return list;
	}
	
	@Transactional(transactionManager = "defaultTransactionManager")
	public List<Integer> addUserQuestionAnswer(List<CovidQuestionAnswer> list)
	{
		Query q=mySqlSession.createNativeQuery("insert into QAUserResponse(userId,questionId,answerId) values(:id,:qId,:ansId)");
		
		List<Integer> result = new ArrayList<Integer>();
		for(int i=0;i<list.size();i++)
		{
			CovidQuestionAnswer cqa = new CovidQuestionAnswer();
			cqa = list.get(i);
			
			q.setParameter("id", 59190);
			q.setParameter("qId", cqa.getQuestionId());
			q.setParameter("ansId", cqa.getAnswerId());
			Integer res=q.executeUpdate();
			result.add(res);
		}
		return result;	
	}
}
