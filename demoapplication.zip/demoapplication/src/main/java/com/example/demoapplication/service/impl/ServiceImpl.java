package com.example.demoapplication.service.impl;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demoapplication.bean.AnswerList;
import com.example.demoapplication.bean.CovidQuestionAnswer;
import com.example.demoapplication.bean.EmployeeDO;
import com.example.demoapplication.bean.UserDetails;
import com.example.demoapplication.dao.UpdateDAO;
import com.example.demoapplication.dao.impl.DataSourceCheck;
import com.example.demoapplication.response.DetailsList;
import com.example.demoapplication.response.QuestionList;
import com.example.demoapplication.response.ResponseDetails;
import com.example.demoapplication.response.Status;
import com.example.demoapplication.service.IService;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

@Service
public class ServiceImpl implements IService {

	@Autowired
	UpdateDAO updateDAO;
	
	@Autowired
	DataSourceCheck datasourceCheck;


	public List<Object[]> updateIdImplementation() {

		// List<Integer> list = new ArrayList<Integer>();
		List<Object[]> list = null;

		try {
			int newUserId = 65064;

			list = updateDAO.updateDaoImpl(newUserId);
		}catch(Exception e)
		{
			System.out.print(e);;
		}
		System.out.println("Over");
		return list;
	}

	public ResponseDetails getDetails(String id1, String id2) {
		ResponseDetails response = new ResponseDetails();

		Status status = new Status();

		// List<EmployeeDO> employeeList = new ArrayList<EmployeeDO>();

		DetailsList responseList = new DetailsList();

		List<EmployeeDO[]> list = updateDAO.getEmpDetails(id1, id2);

		System.out.println(list);

		if (list != null) {
			status.setStatusMessage("Request successfully processed");
			status.setStatusCode(1);
			response.setStatus(status);
		} else {
			status.setStatusMessage("Request failed to process");
			status.setStatusCode(-1);
			response.setStatus(status);
		}
		

		/*
		 * for(int i=0;i<list.size();i++) { EmployeeDO employeeDO = new EmployeeDO();
		 * int j=0; employeeDO.setEmployeeNumber((String)list.get(i)[j++]);
		 * employeeDO.setEmployeeName((String)list.get(i)[j++]);
		 * employeeDO.setFirstName((String)list.get(i)[j++]);
		 * employeeDO.setLastName((String)list.get(i)[j++]);
		 * employeeDO.setMiddleName((String)list.get(i)[j++]);
		 * employeeDO.setGrade((String)list.get(i)[j++]);
		 * employeeDO.setDesignation((String)list.get(i)[j++]);
		 * employeeDO.setEmailId((String)list.get(i)[j++]);
		 * 
		 * System.out.println(employeeDO); //responseList.add(employeeDO)
		 * employeeList.add(employeeDO); }
		 */
		responseList.setResponseList(list);
		response.setDetails(responseList);
		// response.setDetails(employeeList);

		return response;
	}
	
	public ResponseDetails monthList()
	{
		ResponseDetails response = new ResponseDetails();
		
		String[] monthList = DateFormatSymbols.getInstance().getMonths();
		
		Calendar now = Calendar.getInstance();
		
		Integer currentMonth = now.get(Calendar.MONTH);
		
		List<String> list = new ArrayList<String>();
		
	    String monthName = now.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH ) ;
	    
	    System.out.println(monthName);
	 
		int flag=0;
		
		for (int i = 0; i < monthList.length - 1; i++) {
			if (monthName.equalsIgnoreCase(monthList[i])) {
				flag = 1;
			}
			if (flag == 1 && !monthName.equalsIgnoreCase(monthList[i])) {
				list.add(monthList[i]);
			}
		}
		//currentMonth=4;
		for (int i = 0; i <= currentMonth; i++) {
			list.add(monthList[i]);
		}
		 
		
		System.out.println("The month list is "+list);
		response.setDetails(list);
		return response;
	}
	
	public ResponseDetails updateBankUserId()
	{
		Integer result=datasourceCheck.checkUserId();
		
		Status st=new Status();
		
		st.setStatusMessage("Updated Successfully!!");
		
		ResponseDetails response = new ResponseDetails();
		
		response.setDetails(result);
		response.setStatus(st);
		
		return response;
		
	}
	
	public ResponseDetails setAccountOtp()
	{
		Integer result=datasourceCheck.setOtp();
		
		Status st=new Status();
		
		st.setStatusMessage("Otp Updated Successfully!!");
		
		ResponseDetails response = new ResponseDetails();
		
		response.setDetails(result);
		response.setStatus(st);
		
		return response;
		
	}
	
	public void addUserDetails()
	{
		UserDetails userDetails = new UserDetails();
		List<UserDetails> list = updateDAO.getHRMSDetails();
		
		//System.out.println(list);
		
		for(int i=0;i<list.size();i++)
		{
			userDetails = list.get(i);
			Integer result = updateDAO.checkUserExisted(userDetails.getUserId());
			
			//System.out.println("The service "+userDetails.getUserId());
			if(result > 0)
			{
				Integer updateResult = updateDAO.updateUserData(userDetails);
			}else {
				Integer insertResult = updateDAO.insertData(userDetails);
			}
		}
	}
	
	public Integer addImage(MultipartFile imgFile)
	{
		System.out.println("The original file name is "+imgFile.getOriginalFilename());
		 String currentDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		 String path = "D:\\"+currentDate+"\\59190";
		 
		String imgFileName = FilenameUtils.getBaseName(imgFile.getOriginalFilename()).concat(new SimpleDateFormat("_dd-MM-yyyyHHmmss").format(new Date())) + "." + 
					FilenameUtils.getExtension(imgFile.getOriginalFilename());
		
		 File file = new File(path);
		 
		int result=0;
		System.out.println(file.exists());
		
		if (!file.exists()) {
			if (file.mkdirs()) {
				System.out.println("Employee folder is created!!");
				 try {
					 imgFile.transferTo(new File(path, imgFileName));
					 result = 1;
						/*
						 * imgFile.transferTo(new File("D:\\images", imgFile.getOriginalFilename()));
						 * String path1 = "D:\\images\\"+imgFile.getOriginalFilename(); File imagesPath
						 * = new File(path1); if(imagesPath.exists()) { String copy = path+imgFileName;
						 * imagesPath.renameTo(new File(copy)); result=1; }
						 */
					} catch (IllegalStateException | IOException e) {
						e.printStackTrace();
						result=0;
					}
			}
		} else {
			System.out.println("Folder existed!!");
			 try {
					imgFile.transferTo(new File(path, imgFileName));
					result = 1;
				} catch (IllegalStateException | IOException e) {
					e.printStackTrace();
					result=0;
				}
		}
		 return result;
	}
	
	public Integer copyDirectories(String spath, String dpath)
	{	
		Integer result = 0;
		File srcpath = new File(spath);
		File destpath = new File(dpath);
	
		if(srcpath.exists())
		{
			try {
				//Files.move(destpath.toPath(), newName, null);
				FileUtils.copyDirectory(srcpath, destpath,false);
				
				/*
				 * File renameFolder = new File(dpath);
				 * //System.out.println(renameFolder.getParent()); renameFolder.renameTo(new
				 * File(renameFolder.getParent()+"\\"+newFolderName));
				 */
				  result = 1;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				result = 0;
			}
		}
		/*
		 * String destList = dpath; File destListPath = new File(destList);
		 * System.out.println(destListPath); File[] fList = destListPath.listFiles();
		 * for(int i=0;i<fList.length;i++) { System.out.print(i+" "+fList[i]+" "); }
		 * if(fList != null) System.out.println("Hai"); for (File file : fList) { if
		 * (file.isDirectory()) { dpath = destpath+file.getName()+(new
		 * SimpleDateFormat("_dd-MM-yyyyHHmmss").format(new Date()));
		 * file.renameTo(destpath); result = 1; } }
		 */
		return result;
	}
	
	public ResponseDetails questionAnswer()
	{
		Status status = new Status();
		ResponseDetails response = new ResponseDetails();
		
		List<Object[]> list = updateDAO.qntAnswer();
		List<CovidQuestionAnswer> covidAnswerList = null;

		QuestionList questionList = new QuestionList();
		
		if(list!=null)
		{
			status.setStatusCode(1);
			status.setStatusMessage("Request successfully processed");
			response.setStatus(status);
			covidAnswerList = new ArrayList<CovidQuestionAnswer>();
			for (int i=0;i<list.size();i=i+2)
			{	
				CovidQuestionAnswer cqa = new CovidQuestionAnswer();
				if((Integer)list.get(i)[0]==4)
				{
					List<String> questionBulletsList = new ArrayList<String>();
					questionBulletsList.add("Fever or Chills");
					questionBulletsList.add("Cough");
					questionBulletsList.add("Fatigue");
					questionBulletsList.add("Muscle or Body Ache");
					questionBulletsList.add("Headache");
					questionBulletsList.add("New loss of taste or smell");
					questionBulletsList.add("Sore throat");
					questionBulletsList.add("Congestion or runny nose");
					questionBulletsList.add("Nausea or Vomitting");
					questionBulletsList.add("Diarrhea");
					                    
					cqa.setQuestionBullets(questionBulletsList);
				}
				else
				{	
					cqa.setQuestionBullets(null);	
				}
				cqa.setQuestionId((Integer)list.get(i)[0]);
				cqa.setQuestionText((String)list.get(i)[1]);
				cqa.setIcon((String)list.get(i)[2]);
				//covidAnswerList.add(cqa);
				
				List<AnswerList> ansList=new ArrayList<AnswerList>();
				AnswerList aList = new AnswerList();
				
				aList.setAnswerId((Integer)list.get(i)[3]);
				aList.setAnswer((String)list.get(i)[4]);
				
				ansList.add(aList);
				AnswerList aList1 = new AnswerList();
				aList1.setAnswerId((Integer)list.get(i+1)[3]);
				aList1.setAnswer((String)list.get(i+1)[4]);
				ansList.add(aList1);
				
				cqa.setAnswerList(ansList);
				covidAnswerList.add(cqa);
			}
			questionList.setQuestionList(covidAnswerList);
			response.setDetails(questionList);
		}
		else
		{
			status.setStatusCode(-1);
			status.setStatusMessage("Request failed to process");
		}
		return response;
	}
	
	public Status addUserQuestionAnswer(List<CovidQuestionAnswer> covidList)
	{
		List<Integer> list = updateDAO.addUserQuestionAnswer(covidList);
		Status status = new Status();
		boolean b = list.contains(0);
		if(b!=true)
		{
			status.setStatusCode(2);
			status.setStatusMessage("Request successfully processed");
		}
		else {
			status.setStatusCode(-2);
			status.setStatusMessage("Request failed to process");
		}
		return status;
		
	}
	
	public Status readImageFile(String path)
	{
		
		Status status = new Status();
		    ITesseract instance = new Tesseract();
		    String result=null;
		    try {
		    	
		    	instance.setDatapath("C:\\Users\\zensar.MININT-7DU1KHE\\Downloads\\demoapplication\\demoapplication\\tessdata");
		    	//D:\\tessdata
	
		    	instance.setLanguage("eng");
		        
		        result = instance.doOCR(new File(path));
		      
		        System.out.println("The result is "+result);
		        //List<String> list = new ArrayList<String>();
		          
		        Integer startIndex = result.indexOf("Name");
		        Integer endIndex = result.indexOf("Fat");
		       
		        String nameResult = result.substring(startIndex, endIndex);
		        
		        List<String> nameList = parse(nameResult); 
		      
		        //nameList.removeAll(list);
		        System.out.println("The name list is "+nameList);
		        String userName=" ";
		        for(int i=0;i<nameList.size()-1;i++)
		        {
		        	userName+= nameList.get(i)+" ";
		        }
		        userName+=nameList.get(nameList.size()-1);
		        
		       System.out.println("The name of user is "+userName);
		       
		    } catch (TesseractException e) {  
		        System.err.println(e.getMessage());  
		        result=null; 
		    } 

			if (result != null) {
				status.setStatusCode(3);
				status.setStatusMessage("Image processed successfully!!");
			} else {
				status.setStatusCode(-3);
				status.setStatusMessage("Error while reading image");
			}
		 
		    return status;
	}
	
	private List<String> parse(String str) {
	    List<String> output = new ArrayList<String>();
	    String excluse_regex = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
	    String incluse_regex = "[A-Z][A-Z][A-Z]+";
	    
	    //String regex = "(?!" + excluse_regex+ ")" +incluse_regex;
	    
	    String regex = incluse_regex;
	    Matcher match = Pattern.compile(regex).matcher(str);
	    while (match.find()) {
	        output.add(match.group());
	    }
	    return output;
	}
	
	public Status readPdfFile(String path,String imageName)
	{
		Status status = new Status();
		   File newFile = new File(path); 
	  
	        BufferedImage img;
			try {
				
				PDDocument pdfDocument = PDDocument.load(newFile); 
				  
		        PDFRenderer pdfRenderer = new PDFRenderer(pdfDocument); 
		        
				img = pdfRenderer.renderImage(0);
				
				String pdfImagePath = "D:\\images"+"\\"+imageName;
				
				System.out.println("path "+pdfImagePath);
				
			    ImageIO.write(img, "PNG",new File(pdfImagePath)); 
			    
		        System.out.println("Image has been extracted successfully"); 
		        
		        status = readImageFile(pdfImagePath);
		        if(status.getStatusCode()>0)
		        {
		        	status.setStatusCode(4);
		        	status.setStatusMessage("Pdf processed successfully!!");
		        } else {
		        	status.setStatusCode(-4);
		        	status.setStatusMessage("Failed to process the pdf");
		        }
		  
		        // Closing the PDF document 
		        pdfDocument.close(); 
		        
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return status;
			} 
			return status;
	}
	public Status readImageFileForPdf(String path)
	{
		
		Status status = new Status();
		    ITesseract instance = new Tesseract();
		    String result=null;
		    try {
		    	
		    	instance.setDatapath("C:\\Users\\zensar.MININT-7DU1KHE\\Downloads\\demoapplication\\demoapplication\\tessdata");
		    	//D:\\tessdata
	
		    	instance.setLanguage("eng");
		        
		        result = instance.doOCR(new File(path));
		      
		        System.out.println("The result is "+result);
		        //int j=0;
		        List<String> list = new ArrayList<String>();
		        Integer startIndex = result.indexOf("Card");
		        //System.out.println("endIndex "+endIndex);
		        
		        Integer endIndex = result.indexOf("Fat");
		        //System.out.println("Index"+startIndex);
		       
		        String nameResult = result.substring(startIndex, endIndex);
		        
		        List<String> nameList = parse(nameResult); 
		        
		        System.out.println("The list is "+nameList);
		        
		        list.add("OIS");
		        list.add("PAN");
		        list.add("EENS");
		        list.add("RSACOR");
		        list.add("SRR");
		        list.add("RGN");
		       nameList.removeAll(list);
		       System.out.println("The list is "+nameList);
		      String userName = " ";
		      for(int i=2;i<nameList.size()-1;i++)
		      {
		    	  userName+=nameList.get(i)+" ";
		      }
		        userName = userName+nameList.get(nameList.size()-1);
		        System.out.println("The name of user is "+userName);
		    } catch (TesseractException e) {  
		        System.err.println(e.getMessage());  
		        result=null; 
		    } 

			if (result != null) {
				status.setStatusCode(3);
				status.setStatusMessage("Image processed successfully!!");
			} else {
				status.setStatusCode(-3);
				status.setStatusMessage("Error while reading image");
			}
		 
		    return status;
	}
	
	public void processImg(BufferedImage ipimage, float scaleFactor, float offset)
	{
		File f = new File("D:\\images\\text.png");
		//BufferedImage ipimage=null;
		try {
			ipimage = ImageIO.read(f);
		BufferedImage opimage = new BufferedImage(1050, 1024, ipimage.getType());
		Graphics2D graphic = opimage.createGraphics(); 
		  graphic.drawImage(ipimage, 0, 0, 1050, 1024, null); 
		  graphic.dispose(); 
		RescaleOp rescale = new RescaleOp(scaleFactor, offset, null); 
		BufferedImage fopimage  = rescale.filter(opimage, null); 
		ImageIO .write(fopimage, "jpg", new File("D:\\Tess4J\\Testing and learning\\output.png")); 
		
		 Tesseract it = new Tesseract(); 
	     //it.setDatapath("D:\\Program Files\\Workspace\\Tess4J"); 
	     String str = it.doOCR(fopimage); 
	     System.out.println(str); 
		 
	     double d = ipimage.getRGB(ipimage.getTileWidth() / 2, ipimage.getTileHeight() / 2);
	     if (d >= -1.4211511E7 && d < -7254228) { 
	            processImg(ipimage, 3f, -10f); 
	        } 
	        else if (d >= -7254228 && d < -2171170) { 
	            processImg(ipimage, 1.455f, -47f); 
	        } 
	        else if (d >= -2171170 && d < -1907998) { 
	            processImg(ipimage, 1.35f, -10f); 
	        } 
	        else if (d >= -1907998 && d < -257) { 
	            processImg(ipimage, 1.19f, 0.5f); 
	        } 
	        else if (d >= -257 && d < -1) { 
	            processImg(ipimage, 1f, 0.5f); 
	        } 
	        else if (d >= -1 && d < 2) { 
	            processImg(ipimage, 1f, 0.35f); 
	        }
		} catch (IOException | TesseractException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void extractpdfText()
	{
		File file = new File("C:\\Users\\zensar.MININT-7DU1KHE\\Documents\\Personal-Certificates-copy\\ThimmidiPravallika_Resume.pdf");   
		try {
			PDDocument doc = PDDocument.load(file);
			PDFTextStripper pdfStripper = new PDFTextStripper(); 
			System.out.println("The number of pages "+doc.getNumberOfPages());
			//pdfStripper.
			String text = pdfStripper.getText(doc); 
			
			System.out.println("The text is "+text);
			doc.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
}
