package com.example.demoapplication.dao;

import java.util.List;

import com.example.demoapplication.bean.CovidQuestionAnswer;
import com.example.demoapplication.bean.EmployeeDO;
import com.example.demoapplication.bean.UserDetails;

public interface UpdateDAO {

	//Integer updateDaoImpl(int oldId,int newId);
	
	List<Object[]> updateDaoImpl(int newId);
	
	//List<Object[]> getEmpDetails();
	
	List<EmployeeDO[]> getEmpDetails(String id1, String id2);
	
	List<UserDetails> getHRMSDetails();
	
	Integer checkUserExisted(Integer userId);
	
	Integer insertData(UserDetails userDetails);
	
	Integer updateUserData(UserDetails userDetails);
	
	List<Object[]> qntAnswer();
	
	List<Integer> addUserQuestionAnswer(List<CovidQuestionAnswer> list);
}
