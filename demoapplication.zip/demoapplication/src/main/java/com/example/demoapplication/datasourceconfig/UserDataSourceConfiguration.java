
package com.example.demoapplication.datasourceconfig;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class UserDataSourceConfiguration {
	
	@Autowired
	DataBaseConfiguration jpaAdapter;

	@Bean(name = "userEM")
	@ConfigurationProperties(prefix = "spring.user.datasource")
	public DataSource mysqlDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean userEntityManager(@Qualifier("userEM") DataSource dataSource) {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
		entityManagerFactoryBean.setDataSource(dataSource);
		entityManagerFactoryBean.setJpaVendorAdapter(jpaAdapter.getJpaVendorAdapter());
		entityManagerFactoryBean.setPersistenceUnitName("banking_DB");
		entityManagerFactoryBean.setPackagesToScan("com.example.demoapplication.bean");
		entityManagerFactoryBean.setJpaProperties(jpaProperties());

		return entityManagerFactoryBean;
	}

	private Properties jpaProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		// properties.put("hibernate.dialect",
		// "org.hibernate.dialect.Oracle10gDialect");
		return properties;
	}

	@Bean(name = "userTransactionManager")
	public PlatformTransactionManager userTransactionManager() {
		JpaTransactionManager tm = new JpaTransactionManager();
		tm.setEntityManagerFactory(userEntityManager(mysqlDataSource()).getObject());
		return tm;
	}
	 
}
