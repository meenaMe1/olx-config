package com.example.demoapplication.response;

import java.util.List;

public class DetailsList {
	
	private List ResponseList;

	public List getResponseList() {
		return ResponseList;
	}

	public void setResponseList(List responseList) {
		ResponseList = responseList;
	}
	
}
