package com.example.demoapplication.service;

import java.awt.image.BufferedImage;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.example.demoapplication.bean.CovidQuestionAnswer;
import com.example.demoapplication.response.ResponseDetails;
import com.example.demoapplication.response.Status;

public interface IService {

	//void updateIdImplementation(String path);
	
	List<Object[]> updateIdImplementation();
	
	ResponseDetails getDetails(String id1,String id2);
	
	ResponseDetails monthList();
	
	ResponseDetails updateBankUserId();
	
	ResponseDetails setAccountOtp();
	
	void addUserDetails();
	
	Integer addImage(MultipartFile file);
	
	Integer copyDirectories(String path, String dpath);
	
	ResponseDetails questionAnswer();
	
	Status addUserQuestionAnswer(List<CovidQuestionAnswer> covidList);
	
	Status readImageFile(String path);
	
	 void processImg(BufferedImage ipimage, float scaleFactor, float offset);
	 
	 Status readPdfFile(String path,String imageName);
	 
	 void extractpdfText();
	
}
