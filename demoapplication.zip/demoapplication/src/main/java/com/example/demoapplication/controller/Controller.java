package com.example.demoapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demoapplication.bean.CovidQuestionAnswer;
import com.example.demoapplication.bean.EmployeeDO;
import com.example.demoapplication.response.ResponseDetails;
import com.example.demoapplication.response.Status;
import com.example.demoapplication.service.IService;

@RestController
@RequestMapping("/users")
public class Controller {

	@Autowired
	IService updateService;
	
	//@Autowired
	//SchedulerImpl scheduler;
	
	@PostMapping(value = "/home1")
	public @ResponseBody String home()
	{
		return "Happy home";
	}
	
	@GetMapping(value = "/id")
	public @ResponseBody List<Object[]> updateId()
	{
		List<Object[]> list = updateService.updateIdImplementation();
		return list;
		//return "success";
	}
	
	@PostMapping(value = "/getemployeedetails")
	public @ResponseBody ResponseDetails getDetails(@RequestParam String id1,@RequestParam String id2)
	{	
		ResponseDetails responseDetails= updateService.getDetails(id1,id2);
		
		return responseDetails;
	}
	
	@GetMapping(value = "/getmonthslist")
	public @ResponseBody ResponseDetails monthList()
	{
		ResponseDetails response = updateService.monthList();
		return response;
	}
	
	@PostMapping(value = "/updateUserId")
	public @ResponseBody ResponseDetails updateBankId()
	{
		ResponseDetails response = updateService.updateBankUserId();
		
		return response;
	}
	
	@PostMapping(value = "/updateOtp")
	public @ResponseBody ResponseDetails updateOtp()
	{
		ResponseDetails response = updateService.setAccountOtp();
		
		return response;
	}
	
	@PostMapping(value = "/hrmsdetails")
	public @ResponseBody void getHRMS()
	{
		 updateService.addUserDetails();	
		//return response;
	}
	
	@RequestMapping(value = "/addimage", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public @ResponseBody Status addImageService(@RequestParam(required = true, value = "file") MultipartFile file) {
		
		Status response = new Status();
		System.out.println(file.getOriginalFilename());

		Integer result = updateService.addImage(file);
		if (result > 0) {
			response.setStatusCode(5);
			response.setStatusMessage("The image added successfully!!");
		} else {
			response.setStatusCode(-5);
			response.setStatusMessage("Failed to add the image");
		}
		return response;
	}
	
	@PostMapping(value = "/copyfolder")
	public @ResponseBody Status copyDirectoryService(@RequestBody EmployeeDO empDO)
	{
		Status response = new Status();
		Integer result = updateService.copyDirectories(empDO.getPath(),empDO.getDpath());
		
		if(result>0)
		{
			response.setStatusCode(6);
			response.setStatusMessage("The folder copied successfully!!");
		}else {
			response.setStatusCode(-6);
			response.setStatusMessage("Failed to copy the folder");
		}
		return response;
	}
	
	@GetMapping(value = "/covidqna")
	public @ResponseBody ResponseDetails questionAnswerService()
	{
		ResponseDetails response = updateService.questionAnswer();
		return response;
	}
	
	@PostMapping(value = "/adduserqna")
	public @ResponseBody Status addUserQuestionAnswerService(@RequestBody List<CovidQuestionAnswer> list)
	{
		Status status = new Status();
		status = updateService.addUserQuestionAnswer(list);
		
		return status;
	}
	
	
	@PostMapping(value = "/readimage")
	public @ResponseBody Status readImageService(@RequestBody EmployeeDO empDO)
	{
		Status status = new Status();
		status = updateService.readImageFile(empDO.getPath());
		
		return status;
	}
	
	@PostMapping(value = "/readpdf")
	public @ResponseBody Status readPdfService(@RequestBody EmployeeDO empDO)
	{
		Status status = new Status();
		status = updateService.readPdfFile(empDO.getPath(),empDO.getImageName());
		
		//updateService.extractpdfText();
		
		return status;
	}
	
	
	
}
