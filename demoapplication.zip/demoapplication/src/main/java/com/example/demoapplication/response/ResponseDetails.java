
package com.example.demoapplication.response;

public class ResponseDetails {

	private Status status;
	private Object details;
	
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Object getDetails() {
		return details;
	}

	public void setDetails(Object details) {
		this.details = details;
	}

	
	

	
	
	
}
