package com.example.demoapplication.bean;

public class UserDetails {
	
	private Integer userId;
	private String userName;
	private String designation;
	private String grade;
	private String practice;
	private String subPractice;
	private Integer managerId;
	private String managerName;
	private String profilePicUrl;
	private String ServiceLine;
	private Integer activeStatus;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getPractice() {
		return practice;
	}
	public void setPractice(String practice) {
		this.practice = practice;
	}
	public String getSubPractice() {
		return subPractice;
	}
	public void setSubPractice(String subPractice) {
		this.subPractice = subPractice;
	}
	public Integer getManagerId() {
		return managerId;
	}
	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getProfilePicUrl() {
		return profilePicUrl;
	}
	public void setProfilePicUrl(String profilePicUrl) {
		this.profilePicUrl = profilePicUrl;
	}
	public String getServiceLine() {
		return ServiceLine;
	}
	public void setServiceLine(String serviceLine) {
		ServiceLine = serviceLine;
	}
	public Integer getActiveStatus() {
		return activeStatus;
	}
	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	
}
