package com.example.demoapplication.response;

import java.util.List;

public class QuestionList {
	
	private List questionList;

	public List getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List questionList) {
		this.questionList = questionList;
	}

	
}
