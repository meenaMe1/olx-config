package com.zensar.repository;

public interface UpdateRepository {

	String updateQuery();
	
}
