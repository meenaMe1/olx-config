package com.zensar.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zensar.constants.QueryConstant;

@Repository
@Transactional
public class UpdateRepositoryImpl implements UpdateRepository {

	@Autowired
	private EntityManagerFactory entityManager;
	
	@Autowired
	private QueryConstant queryConstants;
	
	@PersistenceContext(unitName = "ORACLE_DB")
	private EntityManager updateSession;
	
	@PersistenceContext(unitName = "MYSQL_DB")
	private EntityManager mySqlSession;
	
	@Override
	public String updateQuery() {
		EntityManager session =entityManager.createEntityManager();
		int userName;
		List<String> list = new ArrayList<>();
		
		try {
			userName = mySqlSession.createNativeQuery(queryConstants.getUpdateQuery()).executeUpdate();
		    list =	(List<String>) updateSession.createNativeQuery(queryConstants.getOracleQuery()).getResultList();
			System.out.println(userName);
			System.out.println(list);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
