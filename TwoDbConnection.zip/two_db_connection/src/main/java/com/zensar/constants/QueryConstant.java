package com.zensar.constants;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:update-query.properties"})
@ConfigurationProperties
public class QueryConstant {

	private String updateQuery;
	private String oracleQuery;

	public String getUpdateQuery() {
		return updateQuery;
	}

	public void setUpdateQuery(String updateQuery) {
		this.updateQuery = updateQuery;
	}

	public String getOracleQuery() {
		return oracleQuery;
	}

	public void setOracleQuery(String oracleQuery) {
		this.oracleQuery = oracleQuery;
	}	
	
}
