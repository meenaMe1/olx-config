package com.zensar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwoDbConnectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwoDbConnectionApplication.class, args);
	}

}
