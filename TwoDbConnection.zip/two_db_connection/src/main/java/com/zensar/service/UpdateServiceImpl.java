package com.zensar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.repository.UpdateRepository;

@Service
public class UpdateServiceImpl implements UpdateService {

	@Autowired
	UpdateRepository updateRepo;
	
	@Override
	public String updateQuery() {
		return updateRepo.updateQuery();
		
	}

}
