package com.zensar.service;

public interface UpdateService {

	String updateQuery();

}
