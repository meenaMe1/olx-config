package MyApp;

import java.util.concurrent.TimeUnit;

import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.google.common.base.Verify;

public class GoogleTest {

	public static void main(String[] args) throws InterruptedException {
	
		System.setProperty("webdriver.gecko.driver", "C:\\Training\\geckodriver-v0.23.0-win32\\geckodriver.exe");
		
//		WebDriver driver= new FirefoxDriver();
		
		System.setProperty("webdriver.chrome.driver", "C:\\Training\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		
		System.setProperty("webdriver.ie.driver", "C:\\AutomationTrainingNovBatch\\AutomationTesting\\lib\\IEDriverServer.exe");
//		WebDriver driver= new InternetExplorerDriver();
//		WebDriver driver= new SafariDriver();
//		WebDriver driver= new OperaDriver();
		
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://www.google.com");
		
//		Thread.sleep(5000);
//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.name("q")).clear();
		driver.findElement(By.name("q")).sendKeys("Zensar");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		System.out.println(driver.getTitle());
		driver.navigate().refresh();
		driver.navigate().back();
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		driver.navigate().forward();
		driver.close();
		driver.quit();
		driver.findElement(By.name("q")).clear();
		driver.findElement(By.name("q")).sendKeys("Automation Testing");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
		
	}
	
	
	
}
