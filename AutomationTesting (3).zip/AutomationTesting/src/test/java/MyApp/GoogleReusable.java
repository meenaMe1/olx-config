package MyApp;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class GoogleReusable {

	WebDriver driver;

	public void startBrowser(String browserName) {

		if (browserName.toUpperCase() == "CH") {

			System.setProperty("webdriver.chrome.driver", "C:\\Training\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();

		}
		if (browserName.toUpperCase() == "FF") {

			System.setProperty("webdriver.gecko.driver", "C:\\Training\\geckodriver-v0.23.0-win32\\geckodriver.exe");
			driver = new FirefoxDriver();

		}
		if (browserName.toUpperCase() == "IE") {

			System.setProperty("webdriver.ie.driver", "C:\\AutomationTrainingNovBatch\\AutomationTesting\\lib\\IEDriverServer.exe");
			 driver= new InternetExplorerDriver();

		}

		driver.manage().window().maximize();
	}

	public void launchURL(String URL) {
		driver.get(URL);
	}

	public void search(String searchKeyword) {
		driver.findElement(By.name("q")).clear();
		driver.findElement(By.name("q")).sendKeys(searchKeyword);
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);

	}
	
	public void searchOnAP(String searchKey) {
		//input [@placeholder='Search']
		
		driver.findElement(By.xpath("//input [@placeholder='Search']")).clear();
		driver.findElement(By.xpath("//input [@placeholder='Search']")).sendKeys(searchKey);
	}
	
	
	public void closeBrowser() {
		driver.quit();
	}

}
