package com.zensar.zenmails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZenMailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
