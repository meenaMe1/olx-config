package com.zensar.zenmails.utils;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Component
public class SecurityUtil {

	private Logger log = LoggerFactory.getLogger(SecurityUtil.class);

	public ResponseEntity<String> callRestTemplates(String uri, MultipartFile multipartFile) {

		ResponseEntity<String> rssResponse = null;
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.add("handshakeToken", "1203sendemail2018");
		requestHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
		MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
		if(multipartFile!=null) {
	        FileSystemResource file = new FileSystemResource(new File(multipartFile.getOriginalFilename()));
		map.add("file", file);
		}
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(map, requestHeaders);
		try {
			rssResponse = restTemplate.postForEntity(uri, requestEntity, String.class);

		} catch (Exception e) {
			log.error("Exception in SecurityUtil class - callRestTemplates");
		}
		return rssResponse;
	}

}
