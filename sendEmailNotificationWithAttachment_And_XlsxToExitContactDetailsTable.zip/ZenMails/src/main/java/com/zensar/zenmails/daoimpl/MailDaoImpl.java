package com.zensar.zenmails.daoimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.zensar.zenmails.beans.ExitContactDetails;
import com.zensar.zenmails.beans.UserVaccinationDetails;
import com.zensar.zenmails.constants.QueryConstants;
import com.zensar.zenmails.dao.MailDao;
import com.zensar.zenmails.utils.SecurityUtil;

@Repository
@Transactional
public class MailDaoImpl implements MailDao {

	@Autowired
	SecurityUtil securityUtil;
	
	@Autowired
	private EntityManagerFactory entityManager;

	@Autowired
	private QueryConstants queryConstants;

	@PersistenceContext(unitName = "MYSQL_DB")
	private EntityManager mySqlSession;

	@Override
	public List<UserVaccinationDetails> getUserVaccinationDetailsView() {
		List<UserVaccinationDetails> userVaccinationDetailsList = new ArrayList<>();
		UserVaccinationDetails userVaccinationDetails = null;
		EntityManager session = entityManager.createEntityManager();
		try {
			List<Object[]> resultSet = session.createNativeQuery(queryConstants.getUserVaccinationDetails()).getResultList();
			for (Object[] result : resultSet) {
				userVaccinationDetails = new UserVaccinationDetails();
				userVaccinationDetails.setUserId((int) result[0]);
				userVaccinationDetails.setDose(result[1] != null ? ((String) result[1]).trim() : "");
				userVaccinationDetails.setVaccineDate((Date) result[2]);
				userVaccinationDetails.setVaccineName(result[3] != null ? ((String) result[3]).trim() : "");
				userVaccinationDetails.setCurrentCity(result[4] != null ? ((String) result[4]).trim() : "");
				userVaccinationDetailsList.add(userVaccinationDetails);
			}

		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			if (mySqlSession.isOpen())
				mySqlSession.close();
		}

		return userVaccinationDetailsList;
	}

	public ResponseEntity<String> insertVaccinationDetailsIntoXlsx(List<UserVaccinationDetails> list, MultipartFile multipartFile) {
		String uri = "https://zentalentappdev.zensar.com/miscellaneous-service-zenhelp/sendEmailNotificationWithAttachment?to=meenakshi.bhadouria@zensar.com&from=suraj.petkar@zensar.com&cc=meenakshi.bhadouria@zensar.com&bcc=meenakshi.bhadouria@zensar.com&subject=Text&content=text";
		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("User_Vaccination_Details");
			String[] heading = { "UserId", "Dose", "VaccineDate", "VaccineName", "CurrentCity" };
			Row headerRow = sheet.createRow(0);
			for (int i = 0; i < heading.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(heading[i]);
			}
			CreationHelper creationHelper = workbook.getCreationHelper();
			CellStyle dateStyle = workbook.createCellStyle();
			dateStyle.setDataFormat(creationHelper.createDataFormat().getFormat("DD/MM/YYYY"));
			int rownum = 1;
			for (UserVaccinationDetails u : list) {
				Row row = sheet.createRow(rownum++);
				row.createCell(0).setCellValue(u.getUserId());
				row.createCell(1).setCellValue(u.getDose());
				Cell dateCell = row.createCell(2);
				dateCell.setCellValue(u.getVaccineDate());
				dateCell.setCellStyle(dateStyle);
				row.createCell(3).setCellValue(u.getVaccineName());
				row.createCell(4).setCellValue(u.getCurrentCity());
			}
			for (int i = 0; i < heading.length; i++) {
				sheet.autoSizeColumn(i);
			}
			//Sheet sheet2 = workbook.createSheet("Second");
			FileOutputStream fileOutputStream = new FileOutputStream(
					"D:/TazWorkspace/ZenMails/User_Vaccination_Details.xlsx");
			System.out.println(fileOutputStream.getFD().toString());
			workbook.write(fileOutputStream);
			fileOutputStream.close();
			workbook.close();
			System.out.println("Exel File Generated Successfully...");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return securityUtil.callRestTemplates(uri, multipartFile);
	}

	@Override
	public List<ExitContactDetails> readXlsxFile() {
		ExitContactDetails exitContactDetails = null;
		List<ExitContactDetails> exitContactDetailsList = new ArrayList<>();
		try {
			File file = new File("C:\\Users\\sp61808\\Downloads\\Exit_Contact_Details (8).xlsx");
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Iterator itr = sheet.iterator();
			for(int i=1;i<sheet.getPhysicalNumberOfRows();i++) {
				Row row = sheet.getRow(i);
				Iterator<Cell> cellIterator = row.cellIterator();
				while(cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
				}
				exitContactDetails = new ExitContactDetails();
				exitContactDetails.setDepartmentId(row.getCell(0).getNumericCellValue());
				exitContactDetails.setBuId(row.getCell(1).getNumericCellValue());
				exitContactDetails.setRank(row.getCell(2).getNumericCellValue());
				exitContactDetails.setContactPersonName(row.getCell(3).getStringCellValue());
				exitContactDetails.setContactPersonEmail(row.getCell(4).getStringCellValue());
				exitContactDetails.setContactPersonExt("");
				exitContactDetails.setCity(row.getCell(6).getStringCellValue());
				exitContactDetails.setUserId(row.getCell(7).getNumericCellValue());
				exitContactDetails.setContactPersonMobileNumber(row.getCell(8).getStringCellValue());				
				exitContactDetailsList.add(exitContactDetails);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return exitContactDetailsList;
	}

	@Override
	public ResponseEntity<String> insertXlsxToExitContactDetailsTable(List<ExitContactDetails> exitContactDetailsList) {
		ResponseEntity<String> responseEntity = null;
		ExitContactDetails exitContactDetails = new ExitContactDetails();
		Iterator itr = exitContactDetailsList.iterator();
		int result = 0;
		while(itr.hasNext()) {
			exitContactDetails = (ExitContactDetails) itr.next();
			try {
				result = mySqlSession.createNativeQuery(queryConstants.getInsertXlsxToExitContactDetails())
						.setParameter("departmentId",(int)exitContactDetails.getDepartmentId())
						.setParameter("buId",(int)exitContactDetails.getBuId())
						.setParameter("rank",(int)exitContactDetails.getRank())
						.setParameter("contactPersonName",exitContactDetails.getContactPersonName())
						.setParameter("contactPersonEmail",exitContactDetails.getContactPersonEmail())
						.setParameter("contactPersonExt",exitContactDetails.getContactPersonExt())
						.setParameter("city",exitContactDetails.getCity())
						.setParameter("userId",(int)exitContactDetails.getUserId())
						.setParameter("contactPersonMobileNumber",exitContactDetails.getContactPersonMobileNumber().replace("\"", ""))
						.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally {
				if (mySqlSession.isOpen())
					mySqlSession.close();
			}
		}
		return new ResponseEntity(HttpStatus.OK);
	}
}
