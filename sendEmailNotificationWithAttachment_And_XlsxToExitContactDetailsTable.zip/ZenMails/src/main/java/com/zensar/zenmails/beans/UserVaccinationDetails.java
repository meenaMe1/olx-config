package com.zensar.zenmails.beans;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class UserVaccinationDetails {

	private int userId;
	private String dose;
	private Date vaccineDate;
	private String vaccineName;
	private String currentCity;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getDose() {
		return dose;
	}
	public void setDose(String dose) {
		this.dose = dose;
	}
	public Date getVaccineDate() {
		return vaccineDate;
	}
	public void setVaccineDate(Date vaccineDate) {
		this.vaccineDate = vaccineDate;
	}
	public String getVaccineName() {
		return vaccineName;
	}
	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}
	public String getCurrentCity() {
		return currentCity;
	}
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}
	
	@Override
	public String toString() {
		return "UserVaccinationDetails [userId=" + userId + ", dose=" + dose + ", vaccineDate=" + vaccineDate
				+ ", vaccineName=" + vaccineName + ", currentCity=" + currentCity + "]";
	}
	
	
}
