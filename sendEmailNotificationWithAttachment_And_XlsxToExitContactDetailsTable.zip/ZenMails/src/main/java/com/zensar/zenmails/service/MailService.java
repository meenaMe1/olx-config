package com.zensar.zenmails.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface MailService {

	ResponseEntity<String> sendEmailNotificationWithAttachment(MultipartFile multipartFile);

	ResponseEntity<String> xlsxToExitContactDetailsTable();

}
