package com.zensar.zenmails.dao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.zensar.zenmails.beans.ExitContactDetails;
import com.zensar.zenmails.beans.UserVaccinationDetails;

public interface MailDao {

	List<UserVaccinationDetails> getUserVaccinationDetailsView();

	public ResponseEntity<String> insertVaccinationDetailsIntoXlsx(List<UserVaccinationDetails> list, MultipartFile multipartFile);

	List<ExitContactDetails> readXlsxFile();

	ResponseEntity<String> insertXlsxToExitContactDetailsTable(List<ExitContactDetails> exitContactDetailsList);
}
