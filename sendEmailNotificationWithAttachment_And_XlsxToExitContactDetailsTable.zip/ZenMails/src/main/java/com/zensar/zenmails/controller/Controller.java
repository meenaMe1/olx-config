package com.zensar.zenmails.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.zensar.zenmails.service.MailService;

@RestController
@RequestMapping("/zenmails")
public class Controller {

	@Autowired
	MailService mailService;

	@PostMapping("/sendEmailNotificationWithAttachment")
	public ResponseEntity<String> sendEmailNotificationWithAttachment(@RequestHeader(required = false) String handshakeToken,@RequestParam(value = "uploadFile", required = false) MultipartFile multipartFile,HttpServletRequest request) throws InterruptedException {
		
		return mailService.sendEmailNotificationWithAttachment(multipartFile);	
	}
	
	@PostMapping("/xlsxToExitContactDetailsTable")
	public ResponseEntity<String> xlsxToExitContactDetailsTable() {
		return mailService.xlsxToExitContactDetailsTable();
	}

}
