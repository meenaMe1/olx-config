package com.zensar.zenmails.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.zensar.zenmails.beans.ExitContactDetails;
import com.zensar.zenmails.beans.UserVaccinationDetails;
import com.zensar.zenmails.dao.MailDao;
import com.zensar.zenmails.service.MailService;

@Service
public class MailServiceImpl implements MailService {

	@Autowired
	MailDao mailDao;
	
	@Override
	public ResponseEntity<String> sendEmailNotificationWithAttachment(MultipartFile multipartFile) {
		List<UserVaccinationDetails> userVaccinationDetailsList = new ArrayList<>();
		userVaccinationDetailsList = mailDao.getUserVaccinationDetailsView();
		System.out.println(userVaccinationDetailsList);
		return 	mailDao.insertVaccinationDetailsIntoXlsx(userVaccinationDetailsList, multipartFile);

	}

	@Override
	public ResponseEntity<String> xlsxToExitContactDetailsTable() {
		List<ExitContactDetails> exitContactDetailsList = new ArrayList<>(); 
		exitContactDetailsList = mailDao.readXlsxFile();
		//System.out.println(exitContactDetailsList);
		return mailDao.insertXlsxToExitContactDetailsTable(exitContactDetailsList);
	}

}
