package com.zensar.zenmails.beans;

import org.springframework.stereotype.Component;

@Component
public class ExitContactDetails {
	
	private double departmentId;
	private double buId;
	private double rank;
	private String contactPersonName;
	private String contactPersonEmail;
	private String contactPersonExt;
	private String city;
	private double userId;
	private String contactPersonMobileNumber;
	public double getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(double departmentId) {
		this.departmentId = departmentId;
	}
	public double getBuId() {
		return buId;
	}
	public void setBuId(double buId) {
		this.buId = buId;
	}
	public double getRank() {
		return rank;
	}
	public void setRank(double rank) {
		this.rank = rank;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactPersonEmail() {
		return contactPersonEmail;
	}
	public void setContactPersonEmail(String contactPersonEmail) {
		this.contactPersonEmail = contactPersonEmail;
	}
	public String getContactPersonExt() {
		return contactPersonExt;
	}
	public void setContactPersonExt(String contactPersonExt) {
		this.contactPersonExt = contactPersonExt;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getUserId() {
		return userId;
	}
	public void setUserId(double userId) {
		this.userId = userId;
	}
	public String getContactPersonMobileNumber() {
		return contactPersonMobileNumber;
	}
	public void setContactPersonMobileNumber(String contactPersonMobileNumber) {
		this.contactPersonMobileNumber = contactPersonMobileNumber;
	}
	@Override
	public String toString() {
		return "ExitContactDetails [departmentId=" + departmentId + ", buId=" + buId + ", rank=" + rank
				+ ", contactPersonName=" + contactPersonName + ", contactPersonEmail=" + contactPersonEmail
				+ ", contactPersonExt=" + contactPersonExt + ", city=" + city + ", userId=" + userId
				+ ", contactPersonMobileNumber=" + contactPersonMobileNumber + "]";
	}
	
	
}
