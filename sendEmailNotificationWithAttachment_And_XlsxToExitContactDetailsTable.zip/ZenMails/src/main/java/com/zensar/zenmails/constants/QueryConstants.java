package com.zensar.zenmails.constants;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:mails-queries.properties"})
@ConfigurationProperties
public class QueryConstants {

	private String insertEmailDetails;
	private String userVaccinationDetails;
	private String insertXlsxToExitContactDetails;

	public String getInsertEmailDetails() {
		return insertEmailDetails;
	}

	public void setInsertEmailDetails(String insertEmailDetails) {
		this.insertEmailDetails = insertEmailDetails;
	}

	public String getUserVaccinationDetails() {
		return userVaccinationDetails;
	}

	public void setUserVaccinationDetails(String userVaccinationDetails) {
		this.userVaccinationDetails = userVaccinationDetails;
	}

	public String getInsertXlsxToExitContactDetails() {
		return insertXlsxToExitContactDetails;
	}

	public void setInsertXlsxToExitContactDetails(String insertXlsxToExitContactDetails) {
		this.insertXlsxToExitContactDetails = insertXlsxToExitContactDetails;
	}

	
	
}
