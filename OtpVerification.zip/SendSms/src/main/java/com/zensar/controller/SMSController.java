package com.zensar.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.rest.api.v2010.account.Message.Status;
import com.twilio.rest.api.v2010.account.MessageCreator;
import com.twilio.type.PhoneNumber;
import com.zensar.dto.SMSBean;

@RestController
@RequestMapping("/sms")
public class SMSController {

	private List<String> otpList = new ArrayList<>();

	private SimpMessagingTemplate webSocket;

	@Value("${ACCOUNT_SID}")
	private String ACCOUNT_SID;

	@Value("${AUTH_TOKEN}")
	private String AUTH_TOKEN;

	@Value("${FROM_NUMBER}")
	private String FROM_NUMBER;

	@RequestMapping(value = "/send", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public String sendSms(@RequestBody SMSBean sms) {

		try {
			Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

			String smsText = sms.getMessage() + "\nYour Verification code is : " + generateOtp();
			String mobileNumber = sms.getTo();

			PhoneNumber recieverPhoneNumber = new PhoneNumber(mobileNumber);
			PhoneNumber senderTwilloPhoneNumber = new PhoneNumber(FROM_NUMBER);

			MessageCreator creator = com.twilio.rest.api.v2010.account.Message.creator(recieverPhoneNumber,
					senderTwilloPhoneNumber, smsText);
			Message create = creator.create();

			BigDecimal billingAmount = create.getPrice();
			Status status = create.getStatus();
			System.out.println("Billing Amount : " + billingAmount + " \nStatus : " + status);

			return " Message Send Succesfully";
		} catch (Exception e) {
			return " Message Send Fail";
		}

	}

	@GetMapping("/otp")
	public StringBuffer generateOtp() {
		StringBuffer sb = new StringBuffer();
		Random obj = new Random();
		char[] otp = new char[4];
		for (int i = 0; i < 4; i++) {
			otp[i] = (char) (obj.nextInt(10) + 48);
			sb = sb.append(otp[i]);
		}
		otpList.add(sb.toString());
		if (otpList.size() > 1) {
			otpList.remove(0);
		}
		return sb;
	}

	@PostMapping("/verify/{otp}")
	public String verifyOtp(@PathVariable String otp) {
		System.out.println(otp);
		System.out.println(otpList);
		if(otpList.contains(otp)) {
			return "OTP verified successfully";
		}
		else
			return "OTP is wrong";
	}

	/*
	 * @RequestMapping(value = "/WhatsApp", method = RequestMethod.POST) public
	 * String sendWhatsappMsg() {
	 * 
	 * Twilio.init(ACCOUNT_SID, AUTH_TOKEN); Message message = Message.creator( new
	 * com.twilio.type.PhoneNumber("whatsapp:+919170388724"), new
	 * com.twilio.type.PhoneNumber("whatsapp:"+FROM_NUMBER),
	 * "Hello from your friendly neighborhood Java application!") .create(); return
	 * "Sent"; }
	 */
}
