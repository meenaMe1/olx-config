package com.example.demo.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class CarMain {

	public static void main(String[] args) {
	
		Car car1 = new Car(1, "Red", "Ford", 15);
		Car car2 = new Car(2, "Black", "Maruti", 20);
		Car car3 = new Car(3, "Blue", "Ford", 12);
		Car car4 = new Car(4, "Black", "Kia", 15);
		Car car5 = new Car(1, "Red", "Maruti", 18);
		Car car6 = new Car(2, "Red", "Maruti", 17);
		
		List<Car> carList= new ArrayList<>();
		carList.add(car1);
		carList.add(car2);
		carList.add(car3);
		carList.add(car4);
		carList.add(car5);
		
		Collection<Car> carColorList= functionColor(carList);
		
		System.out.println("Car based on color : "+carColorList);
		Collection<Car> carColorbrandList= functionColorAndBrand(carList);
		System.out.println("Car based on color and brand : "+carColorbrandList);
	
		List<Car> sortedBrandList = functionSortedBrandAndMilege(carList);
		
	System.out.println("sorted List : "+ sortedBrandList);
	
	
	}
	
	public static Collection<Car> functionColor(List<Car> carList) {	
		Map<String, Car> map = new HashMap<>();	
		for(Car car: carList) {		
		map.put(car.getColor(), car);
		}
		Collection<Car> unqcarList =  map.values();	
	return unqcarList;	
	}
	public static Collection<Car> functionColorAndBrand(List<Car> carList) {
		Map<String, Car> map = new HashMap<>();
		for(Car car: carList) {
			map.put(car.getColor().concat(car.getBrand()), car);
		}
		Collection<Car> unqcarList = map.values();		
		return unqcarList;
	}
public static List<Car> functionSortedBrand(List<Car> carList) {
		
	List<Car> unqcarList = carList.stream().sorted(Comparator.comparing(Car:: getBrand)).collect(Collectors.toList());
		return unqcarList;
		
	}

public static List<Car> functionSortedBrandAndMilege(List<Car> carList) {
	
List<Car> unqcarList = carList.stream()
.sorted(Comparator.comparing(Car:: getBrand).thenComparing(Car:: getMilage)).collect(Collectors.toList());
	return unqcarList;
	
}

}
