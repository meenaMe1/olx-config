package com.example.demo.test;

import java.util.ArrayList;
import java.util.List;import java.util.stream.Collector;
import java.util.stream.Collectors;

public class DemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Write code to find the first non repeated character in the String.
		 * 
		 * 
		 * If the word "teeter" is input then it should print 'r' as output. If the word
		 * "stress" is input then it should print 't' as output.
		 */
		/*
		 * String test="teeter";
		 * 
		 * char[] charArr = test.toCharArray();
		 * 
		 * System.out.println(charArr);
		 * 
		 * Map<Character,Integer> map =new LinkedHashMap<>();
		 * 
		 * for(int i=0; i< charArr.length;i++) {
		 * 
		 * if(!map.containsKey(charArr[i])) { map.put(charArr[i], 1);
		 * 
		 * }else { map.put(charArr[i], map.get(charArr[i])+1); } }
		 * 
		 * for(char c : map.keySet()) {
		 * 
		 * System.out.println(c); if(map.get(c)==1) { char nonRepeated = c;
		 * System.out.println("Output Character : "+nonRepeated); break; } }
		 */
		
		
		
		/*
		 * inputList =
		 * {"Java is good ","Python is like Python ","I love JAVA","SQL is interesting "
		 * ,"Shell is not for me","I am still counting C++"} return a list that contains
		 * only the input items that have Java in it. Note: Consider Case insensitivity,
		 * i.e , Java or JAVA , both can be returned
		 */
		
		List<String> strList = new ArrayList<>();
		strList.add("Java is good");
		strList.add("Python is like Python");
		strList.add("I love JAVA");
		strList.add("SQL is interesting");
		strList.add("Shell is not for me");
		List<String> outputList = strList.stream().filter(s -> (s.toLowerCase()).contains("java")).collect(Collectors.toList());
		
		System.out.println(outputList);
	}

}
