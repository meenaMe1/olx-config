package com.example.demo;


		class Car extends Vehicle {
		    // Car attribute
			
			 
			 public void display() {                    // Vehicle method
				    System.out.println("display Car");
				  }
			 
			 public void view() {                    // Vehicle method
				    System.out.println("view Car");
				  }
			 
			 
		 
			 public static void main(String[] args) {

				    // Create a myCar object
					  Vehicle myCar = new Car();

				    // Call the honk() method (from the Vehicle class) on the myCar object
				    myCar.show();
				    myCar.display();
				  //  myCar.view();
				  }
}