package com.example.demo;

public class Vehicle {

	
	 public void show() {                    // Vehicle method
		    System.out.println("Show");
		  }
		  
		  public void display() throws NullPointerException{                    // Vehicle method
			    System.out.println("display");
			  }
}
