package com.example.demo.test;

public class Quest {

	public static void main(String[] args) {
		
		int arr [] = {-2,-1,-7,7,10,1,-1,-2,-7,9,8,4};
		
		
		// -2,-1,-7,-1,-2,-7,7,10,1,9,8,4
		
		for(int i=0; i<arr.length ;i++) {
			
			int temp =1;
			
		if(arr[i]<0) {
			
			int postiveNumb = arr[i];
			int index = i;
			int negativeNum = 0;
			int indexNegNum =0;
			for(int j=i+1 ; j < arr.length-1;j++) {
				
				if(arr[j] <0 ) {
					
					negativeNum =arr[j];
					indexNegNum = j;
				}
				
			}
			
			temp= arr[i];
			arr[i] =negativeNum;
			
			if(i <= indexNegNum) {
			arr[i+1]=postiveNumb;
			//arr[]
			}
		}
		
			
		}
	}

}
