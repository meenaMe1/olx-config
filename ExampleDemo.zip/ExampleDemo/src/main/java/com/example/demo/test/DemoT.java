package com.example.demo.test;

class A {
	
	public  static void display() throws NullPointerException{
		
		System.out.println("A");
	}
	
}

class B extends A{
	
public  static void display(){
		
		System.out.println("B");
	}
	
}


public class DemoT {

	public static void main(String[] args) {
		
		B a = new B();
		
		a.display();
		
	}

}
