package com.example.demo.test;

import java.util.HashMap;
import java.util.Map;



public class MultiThreadingEx {
	
	
	static class A{
		
		
		
	}
	
static class B{
		
	}
	
	
	public static void main(String[] args) {
		
		
		Map<A,B> map = new HashMap<>();
		
		map.put(new A() ,new B());
		map.put(new A(), new B());
		map.put(new A(), new B());
		map.put(new A(), new B());
		map.put(new A(), new B());
		map.put(new A(), new B());
		map.put(new A(), new B());
		
		System.out.println("size : "+map.size());
		
		map.get(new A());
		
	}

}
