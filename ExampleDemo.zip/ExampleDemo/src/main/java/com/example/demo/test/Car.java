package com.example.demo.test;

public class Car {
	
	private int modelNumber;
	
	private String color;
	
	private String brand;
	
	private int milage;

	public int getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(int modelNumber) {
		this.modelNumber = modelNumber;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getMilage() {
		return milage;
	}

	public void setMilage(int milage) {
		this.milage = milage;
	}

	public Car(int modelNumber, String color, String brand, int milage) {
		super();
		this.modelNumber = modelNumber;
		this.color = color;
		this.brand = brand;
		this.milage = milage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		result = prime * result + milage;
		result = prime * result + modelNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (milage != other.milage)
			return false;
		if (modelNumber != other.modelNumber)
			return false;
		return true;
	}

	public Car(String color, String brand) {
		super();
		this.color = color;
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Car [modelNumber=" + modelNumber + ", color=" + color + ", brand=" + brand + ", milage=" + milage + "]";
	}

	
}
