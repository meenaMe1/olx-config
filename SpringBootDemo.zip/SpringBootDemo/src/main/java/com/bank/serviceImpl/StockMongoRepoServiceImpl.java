package com.bank.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dto.Stock;
import com.bank.entity.StockData;
import com.bank.exception.InvalidStockIdException;
import com.bank.repo.StockMongRepo;
import com.bank.service.StockMongoService;

@Service
public class StockMongoRepoServiceImpl implements StockMongoService{

	
	@Autowired
	StockMongRepo stockRepo;


	@Override
	public Stock creatNewStock(Stock stock, String authToken) {
		
		StockData stockData = new StockData(stock.getId(),stock.getName(), stock.getMarketName(),stock.getPrice());
		stockData = stockRepo.save(stockData);
		stock =new Stock(stockData.getId(),stockData.getName(),stockData.getMarketName(),stockData.getPrice());
		return stock;
	}

	@Override
	public List<Stock> getAllStocks() {
		List<StockData> stockEntityList= stockRepo.findAll();
		List<Stock> stockList = new ArrayList<>();
		for(StockData stockEntity :stockEntityList) {
			Stock stock =new Stock(stockEntity.getId(),stockEntity.getName(),stockEntity.getMarketName(),stockEntity.getPrice());
			stockList.add(stock);
		}
		return stockList;
	}

	@Override
	public Stock getStockById(int stockId) {
		Optional<StockData> optionalStockEntity=stockRepo.findById(stockId);
		if(optionalStockEntity.isPresent()) {
			StockData stockEntity = optionalStockEntity.get();
			Stock stock =new Stock(stockEntity.getId(),stockEntity.getName(),stockEntity.getMarketName(),stockEntity.getPrice());
		return stock;
		}
		
		throw new InvalidStockIdException(""+stockId);
	}

	@Override
	public boolean deleteStockById(int stockId) {
	if(stockRepo.existsById(stockId)) {
		stockRepo.deleteById(stockId);
		return true;
	}
		return false;
	}

	@Override
	public Stock updateStockById(int stockId, Stock stock) {
		Optional<StockData> optionalStockEntity=stockRepo.findById(stockId);
		if(optionalStockEntity.isPresent()) {
			StockData stockData = optionalStockEntity.get();
			stockData.setName(stock.getName());
			stockData.setMarketName(stock.getMarketName());
			stockData.setPrice(stock.getPrice());
			stockData = stockRepo.save(stockData);
			stock.setId(stockId);
			return stock;
		}
		
		throw new InvalidStockIdException(""+stockId);
	}


}
