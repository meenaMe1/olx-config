package com.bank.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SampleController {

	@GetMapping(value="/contactus")
	public String getContactUs(Model model) {
		model.addAttribute("fname","Meenakshi");
		return "contact-us";
		
	}
	
}
