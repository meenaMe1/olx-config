package com.bank;

import java.util.Collections;

import org.springframework.boot.actuate.info.Info.Builder;
import org.springframework.boot.actuate.info.InfoContributor;

public class CustomInfo implements InfoContributor{


//{ "total-registered-users": 478, "active-login-count": 35 }
	@Override
	public void contribute(Builder builder) {
		builder.withDetail("info",
                Collections.singletonMap("total-registered-users", "478"));

}
}
