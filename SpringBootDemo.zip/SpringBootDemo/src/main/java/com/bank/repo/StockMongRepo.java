package com.bank.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.bank.entity.StockData;

public interface StockMongRepo extends MongoRepository<StockData, Integer> {

}
