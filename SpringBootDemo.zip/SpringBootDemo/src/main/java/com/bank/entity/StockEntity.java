package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="Stock")
@ToString
@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class StockEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="stock_name")
	private String name;
	
	@Column(name="marketName")
	private String marketName;
	
	@Column(name="price")
	private double price;
	
	

}
