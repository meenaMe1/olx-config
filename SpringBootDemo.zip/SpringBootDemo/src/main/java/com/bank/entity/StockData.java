package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection ="stocks")
@ToString
@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class StockData {

	
	private int id;
	
	
	private String name;
	

	private String marketName;
	
	
	private double price;
}
