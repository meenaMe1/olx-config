package com.bank;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="bug-fixes")
public class BugFixesReportIndicator {

	static Map<String, Object> bugsMap = new HashMap<>();
	
	@PostConstruct
	public void initailized() {
		
		bugsMap.put("v1", Arrays.asList("Windows close not working","Extension not working"));
		bugsMap.put("v2", Arrays.asList("olx not working","login not working"));
		//bugsMap.put("v1", Arrays.asList("Windows close not working","Extension not working"));
	}
	
	@ReadOperation
	public Map<String,Object> getBugFixesInfo(){
		return bugsMap;
		
	}
	
}
