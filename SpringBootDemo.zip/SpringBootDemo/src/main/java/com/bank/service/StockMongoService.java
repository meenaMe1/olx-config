package com.bank.service;

import java.util.List;

import com.bank.dto.Stock;

public interface StockMongoService {
	
	public List<Stock> getAllStocks();
	
	public Stock getStockById(int stockId);
	
	public boolean deleteStockById( int stockId);
	
	public Stock updateStockById( int stockId, Stock updatestock);
	
	Stock creatNewStock(Stock stock, String authToken);

}
