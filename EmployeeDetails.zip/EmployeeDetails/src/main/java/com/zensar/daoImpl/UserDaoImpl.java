package com.zensar.daoImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.zensar.beans.UserDo;
import com.zensar.constants.QueryConstants;
import com.zensar.dao.UserDao;

@Repository
public class UserDaoImpl implements UserDao {
	private Logger log = LoggerFactory.getLogger(UserDaoImpl.class);

	@Autowired
	private EntityManagerFactory entityManager;

	@Autowired
	private QueryConstants queryConstants;

	@PersistenceContext
	private EntityManager mySqlSession;

	@Override
	public List<UserDo> userDetails(int userId) {
		EntityManager session = entityManager.createEntityManager();
		UserDo userInfo = null;
		List<UserDo> listUser = new ArrayList();

		try {
			List<Object[]> resultSet = session.createNativeQuery(queryConstants.getUserDetails())
					.setParameter("userId", userId).getResultList();
			for (Object[] result : resultSet) {
				userInfo = new UserDo();
				userInfo.setUserId((int) result[0]);
				userInfo.setUserName(result[1] != null ? ((String) result[1]).trim() : "");
				userInfo.setEmailId(result[2] != null ? ((String) result[2]).trim() : "");
				userInfo.setFirstName(result[3] != null ? ((String) result[3]).trim() : "");
				userInfo.setMiddleName(result[4] != null ? ((String) result[4]).trim() : "");
				userInfo.setLastName(result[5] != null ? ((String) result[5]).trim() : "");
				userInfo.setGender(result[6] != null ? ((String) result[6]).trim() : "");
				userInfo.setParentBuName(result[7] != null ? ((String) result[7]).trim() : "");
				userInfo.setBuName(result[8] != null ? ((String) result[8]).trim() : "");
				userInfo.setLocation(result[9] != null ? ((String) result[9]).trim() : "");
				userInfo.setCountry(result[10] != null ? ((String) result[10]).trim() : "");
				userInfo.setLoginId(result[11] != null ? ((String) result[11]).trim() : "");
				userInfo.setSupervisorId((int) result[12]);
				userInfo.setBirthDate(result[13] != null ? ((Date) result[13]) : null);
				userInfo.setJoiningDate(result[14] != null ? ((Date) result[14]) : null);
				userInfo.setProfilePicUrl(result[15] != null ? ((String) result[15]).trim() : "");
				userInfo.setPayroll(result[16] != null ? ((String) result[16]).trim() : "");
				userInfo.setJobTitle(result[17] != null ? ((String) result[17]).trim() : "");
				userInfo.setBand(result[18] != null ? ((String) result[18]).trim() : "");
				// userInfo.setActiveSatus((int)result[23]);
				// userInfo.setSourceUserId((int)result[24]);
				userInfo.setPreviousExp((double) result[25]);
				userInfo.setBloodGroup(result[26] != null ? ((String) result[26]).trim() : "");
				userInfo.setCity(result[27] != null ? ((String) result[27]).trim() : "");
				userInfo.setVbu(result[28] != null ? ((String) result[28]).trim() : "");
				userInfo.setTotalExp((double) result[29]);
				userInfo.setSkills(result[30] != null ? ((String) result[30]).trim() : "");
				userInfo.setAwards(result[31] != null ? ((String) result[31]).trim() : "");
				userInfo.setTraining(result[32] != null ? ((String) result[32]).trim() : "");
				userInfo.setArName(result[33] != null ? ((String) result[33]).trim() : "");
				userInfo.setSubPracticeName(result[34] != null ? ((String) result[34]).trim() : "");
				userInfo.setPracticeName(result[35] != null ? ((String) result[35]).trim() : "");
				userInfo.setArEmailId(result[36] != null ? ((String) result[36]).trim() : "");
				userInfo.setArId(result[37] != null ? ((String) result[37]).trim() : "");
				userInfo.setHiredBg(result[38] != null ? ((String) result[38]).trim() : "");
				userInfo.setDepartment(result[39] != null ? ((String) result[39]).trim() : "");
				userInfo.setTerminationDate(result[40] != null ? ((Date) result[40]) : null);
				userInfo.setTerminationNotificationDate(result[41] != null ? ((Date) result[41]) : null);
				listUser.add(userInfo);
			}

			// System.out.println(listUser);
		} catch (NoResultException e) {
			log.error("error in userDetails :" + new Date());
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		return listUser;
	}

	@Override
	public List<UserDo> listOfEmployees(int year) {
		EntityManager session = entityManager.createEntityManager();
		UserDo userInfo = null;
		List<UserDo> listUser = new ArrayList();

		try {
			List<Object[]> resultSet = session.createNativeQuery(queryConstants.getListOfEmployees())
					.setParameter("year", year).getResultList();
			for (Object[] result : resultSet) {
				userInfo = new UserDo();
				userInfo.setUserId((int) result[0]);
				userInfo.setUserName(result[1] != null ? ((String) result[1]).trim() : "");
				userInfo.setEmailId(result[2] != null ? ((String) result[2]).trim() : "");
				userInfo.setFirstName(result[3] != null ? ((String) result[3]).trim() : "");
				userInfo.setMiddleName(result[4] != null ? ((String) result[4]).trim() : "");
				userInfo.setLastName(result[5] != null ? ((String) result[5]).trim() : "");
				userInfo.setGender(result[6] != null ? ((String) result[6]).trim() : "");
				userInfo.setParentBuName(result[7] != null ? ((String) result[7]).trim() : "");
				userInfo.setBuName(result[8] != null ? ((String) result[8]).trim() : "");
				userInfo.setLocation(result[9] != null ? ((String) result[9]).trim() : "");
				userInfo.setCountry(result[10] != null ? ((String) result[10]).trim() : "");
				userInfo.setLoginId(result[11] != null ? ((String) result[11]).trim() : "");
				userInfo.setSupervisorId((int) result[12]);
				userInfo.setBirthDate(result[13] != null ? ((Date) result[13]) : null);
				userInfo.setJoiningDate(result[14] != null ? ((Date) result[14]) : null);
				userInfo.setProfilePicUrl(result[15] != null ? ((String) result[15]).trim() : "");
				userInfo.setPayroll(result[16] != null ? ((String) result[16]).trim() : "");
				userInfo.setJobTitle(result[17] != null ? ((String) result[17]).trim() : "");
				userInfo.setBand(result[18] != null ? ((String) result[18]).trim() : "");
				userInfo.setPreviousExp((double) result[25]);
				userInfo.setBloodGroup(result[26] != null ? ((String) result[26]).trim() : "");
				userInfo.setCity(result[27] != null ? ((String) result[27]).trim() : "");
				userInfo.setVbu(result[28] != null ? ((String) result[28]).trim() : "");
				userInfo.setTotalExp((double) result[29]);
				userInfo.setSkills(result[30] != null ? ((String) result[30]).trim() : "");
				userInfo.setAwards(result[31] != null ? ((String) result[31]).trim() : "");
				userInfo.setTraining(result[32] != null ? ((String) result[32]).trim() : "");
				userInfo.setArName(result[33] != null ? ((String) result[33]).trim() : "");
				userInfo.setSubPracticeName(result[34] != null ? ((String) result[34]).trim() : "");
				userInfo.setPracticeName(result[35] != null ? ((String) result[35]).trim() : "");
				userInfo.setArEmailId(result[36] != null ? ((String) result[36]).trim() : "");
				userInfo.setArId(result[37] != null ? ((String) result[37]).trim() : "");
				userInfo.setHiredBg(result[38] != null ? ((String) result[38]).trim() : "");
				userInfo.setDepartment(result[39] != null ? ((String) result[39]).trim() : "");
				userInfo.setTerminationDate(result[40] != null ? ((Date) result[40]) : null);
				userInfo.setTerminationNotificationDate(result[41] != null ? ((Date) result[41]) : null);
				listUser.add(userInfo);
			}
			// System.out.println(listUser);
		} catch (NoResultException e) {
			log.error("error in listOfEmployees :" + new Date());
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		return listUser;
	}
}