package com.zensar.servicesImpl;

import java.util.Date;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.beans.ResponseDo;
import com.zensar.beans.Status;
import com.zensar.beans.UserDo;
import com.zensar.dao.UserDao;
import com.zensar.services.UserServices;

@Service
public class UserServicesImpl implements UserServices{
	private Logger log=LoggerFactory.getLogger(UserServicesImpl.class);
	
	@Autowired
	UserDao userDao;
	
	@Override
	public ResponseDo userDetails(int userId) {
		log.info("Start of userDetails :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		Status status= new Status();
		try {
		List<UserDo> userDetailsList=userDao.userDetails(userId);
		
		if(userDetailsList!=null) {
			status.setStatusCode(1);
			status.setStatusMessage("User Details Retrived Succesfully");
		}
		else {
			status.setStatusCode(0);
			status.setStatusMessage("Particular User Details are not Retrived");
		}
		 responseDo.setDetails(userDetailsList);
		 responseDo.setStatus(status);
		 return responseDo;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			log.error("error in userDetails :"+e.getStackTrace());
			return null;
		}
	}

	@Override
	public ResponseDo listOfEmployees(int year) {
		log.info("Start of listOfEmployees :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		Status status= new Status();
		try {
		List<UserDo> employeesList=userDao.listOfEmployees(year);
		
		if(employeesList!=null) {
			status.setStatusCode(1);
			status.setStatusMessage("List Of Active Employees Records Retrived Succesfully");
		}
		else {
			status.setStatusCode(0);
			status.setStatusMessage("List Of Active Employees Records not Retrived Succesfully");
		}
		 responseDo.setDetails(employeesList);
		 responseDo.setStatus(status);
		 return responseDo;
		}catch (Exception e) {
			e.printStackTrace();
			log.error("error in listOfEmployees :"+e.getStackTrace());
			return null;
		}
	}
}
