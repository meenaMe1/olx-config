package com.zensar.services;

import java.util.List;

import com.zensar.beans.ResponseDo;
import com.zensar.beans.UserDo;

public interface UserServices {

	public ResponseDo userDetails(int userId);
	public ResponseDo listOfEmployees(int year);
}
