package com.zensar.configurations;

public class DatabaseConfiguration {

}
