package com.zensar.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.zensar.beans.RequestBodyDo;
import com.zensar.beans.ResponseDo;
import com.zensar.beans.Status;
import com.zensar.beans.UserDo;
import com.zensar.services.UserServices;

@RestController
public class UserController {
	private Logger log=LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserServices userServices;
	
	@GetMapping("/getUserDetails")
	public ResponseDo userDetails(@RequestBody RequestBodyDo requestBodyDo) {
		log.info("Start of getUserDetails :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		int userId=requestBodyDo.getUserId();
		try {
		responseDo=userServices.userDetails(userId);
		}
		catch (Exception e) {
			log.error("error in getUserDetails :"+e.getStackTrace());
		}
		return responseDo;	
	}
	
	@GetMapping("/getListOfEmployees")
	public ResponseDo listOfEmployees(@RequestBody RequestBodyDo requestBodyDo) {
		log.info("Start of getListOfEmployees :"+new Date());
		ResponseDo responseDo=new ResponseDo();
		int year=requestBodyDo.getYear();
		try {
		responseDo=userServices.listOfEmployees(year);
		}
		catch (Exception e) {
			log.error("error in getListOfEmployees :"+e.getStackTrace());
		}
		return responseDo;
		
		}
	
	@PostMapping(value = "/uploadDocument")
	public String handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam String emp_Id)
			throws IllegalStateException, IOException {
		log.info("Start of uploadDocument :"+new Date());
		try {
		File dir = new File("D:\\document" + "\\" + emp_Id);
		System.out.println(dir.getPath());
		if (!dir.exists()) {
			dir.mkdirs();
		}
		InputStream input = file.getInputStream();
		OutputStream output = new FileOutputStream(new File(dir.getPath(), file.getOriginalFilename()));
		IOUtils.copy(input, output);
		}
		catch (Exception e) {
			log.error("error in uploadDocument :"+e.getStackTrace());
		}
		return "Document Uploaded Successfully";
	}

}
