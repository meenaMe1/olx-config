package com.zensar.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value="classpath:queries.properties")

public class QueryConstants {

	@Value("${getUserDetails}")
	public String userDetails;
	
	@Value("${getListOfEmployees}")
	public String listOfEmployees;

	public String getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(String userDetails) {
		this.userDetails = userDetails;
	}

	public String getListOfEmployees() {
		return listOfEmployees;
	}

	public void setListOfEmployees(String listOfEmployees) {
		this.listOfEmployees = listOfEmployees;
	}
	
}
