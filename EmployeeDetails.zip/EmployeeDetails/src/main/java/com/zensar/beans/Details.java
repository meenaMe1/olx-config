package com.zensar.beans;

import java.util.List;

public class Details {

	private List<UserDo> userDo;

	public List<UserDo> getUserDo() {
		return userDo;
	}

	public void setUserDo(List<UserDo> userDo) {
		this.userDo = userDo;
	}
	
	
}
