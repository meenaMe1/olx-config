package com.zensar.beans;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class UserDo {

	private int userId;
	private String userName;
	private String emailId;
	private Date joiningDate;
	private String firstName;
	private String middleName;
	private String lastName;
	private String gender;
	private String parentBuName;
	private String buName;
	private String location;
	private String country;
	private String loginId;
	private int supervisorId;
	private Date birthDate;
	private String profilePicUrl;
	private String payroll;
	private String jobTitle;
	private String band;
	private int activeSatus;
	private int sourceUserId;
	private double previousExp;
	private String bloodGroup;
	private String city;
	private String vbu;
	private double totalExp;
	private String skills;
	private String awards;
	private String training;
	private String arName;
	private String subPracticeName;
	private String practiceName;
	private String arEmailId;
	private String arId;
	private String hiredBg;
	private String department;
	private Date terminationDate;
	private Date terminationNotificationDate;
	
	public UserDo() {
		super();
	}

	public UserDo(int userId, String userName, String emailId, String firstName, String middleName, String lastName,
			String gender, String parentBuName, String buName, String location, String country, String loginId,
			int supervisorId, Date birthDate, Date joiningDate, String profilePicUrl, String payroll, String jobTitle,
			String band, int activeSatus, int sourceUserId, double previousExp, String bloodGroup, String city,
			String vbu, double totalExp, String skills, String awards, String training, String arName,
			String subPracticeName, String practiceName, String arEmailId, String arId, String hiredBg,
			String department, Date terminationDate, Date terminationNotificationDate) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.emailId = emailId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.gender = gender;
		this.parentBuName = parentBuName;
		this.buName = buName;
		this.location = location;
		this.country = country;
		this.loginId = loginId;
		this.supervisorId = supervisorId;
		this.birthDate = birthDate;
		this.joiningDate = joiningDate;
		this.profilePicUrl = profilePicUrl;
		this.payroll = payroll;
		this.jobTitle = jobTitle;
		this.band = band;
		this.activeSatus = activeSatus;
		this.sourceUserId = sourceUserId;
		this.previousExp = previousExp;
		this.bloodGroup = bloodGroup;
		this.city = city;
		this.vbu = vbu;
		this.totalExp = totalExp;
		this.skills = skills;
		this.awards = awards;
		this.training = training;
		this.arName = arName;
		this.subPracticeName = subPracticeName;
		this.practiceName = practiceName;
		this.arEmailId = arEmailId;
		this.arId = arId;
		this.hiredBg = hiredBg;
		this.department = department;
		this.terminationDate = terminationDate;
		this.terminationNotificationDate = terminationNotificationDate;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getParentBuName() {
		return parentBuName;
	}

	public void setParentBuName(String parentBuName) {
		this.parentBuName = parentBuName;
	}

	public String getBuName() {
		return buName;
	}

	public void setBuName(String buName) {
		this.buName = buName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public int getSupervisorId() {
		return supervisorId;
	}

	public void setSupervisorId(int supervisorId) {
		this.supervisorId = supervisorId;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public String getProfilePicUrl() {
		return profilePicUrl;
	}

	public void setProfilePicUrl(String profilePicUrl) {
		this.profilePicUrl = profilePicUrl;
	}

	public String getPayroll() {
		return payroll;
	}

	public void setPayroll(String payroll) {
		this.payroll = payroll;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public int getActiveSatus() {
		return activeSatus;
	}

	public void setActiveSatus(int activeSatus) {
		this.activeSatus = activeSatus;
	}

	public int getSourceUserId() {
		return sourceUserId;
	}

	public void setSourceUserId(int sourceUserId) {
		this.sourceUserId = sourceUserId;
	}

	public double getPreviousExp() {
		return previousExp;
	}

	public void setPreviousExp(double previousExp) {
		this.previousExp = previousExp;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getVbu() {
		return vbu;
	}

	public void setVbu(String vbu) {
		this.vbu = vbu;
	}

	public double getTotalExp() {
		return totalExp;
	}

	public void setTotalExp(double totalExp) {
		this.totalExp = totalExp;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getAwards() {
		return awards;
	}

	public void setAwards(String awards) {
		this.awards = awards;
	}

	public String getTraining() {
		return training;
	}

	public void setTraining(String training) {
		this.training = training;
	}

	public String getArName() {
		return arName;
	}

	public void setArName(String arName) {
		this.arName = arName;
	}

	public String getSubPracticeName() {
		return subPracticeName;
	}

	public void setSubPracticeName(String subPracticeName) {
		this.subPracticeName = subPracticeName;
	}

	public String getPracticeName() {
		return practiceName;
	}

	public void setPracticeName(String practiceName) {
		this.practiceName = practiceName;
	}

	public String getArEmailId() {
		return arEmailId;
	}

	public void setArEmailId(String arEmailId) {
		this.arEmailId = arEmailId;
	}

	public String getArId() {
		return arId;
	}

	public void setArId(String arId) {
		this.arId = arId;
	}

	public String getHiredBg() {
		return hiredBg;
	}

	public void setHiredBg(String hiredBg) {
		this.hiredBg = hiredBg;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Date getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	public Date getTerminationNotificationDate() {
		return terminationNotificationDate;
	}

	public void setTerminationNotificationDate(Date terminationNotificationDate) {
		this.terminationNotificationDate = terminationNotificationDate;
	}

	@Override
	public String toString() {
		return "UserDo [userId=" + userId + ", userName=" + userName + ", emailId=" + emailId + ", firstName="
				+ firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", gender=" + gender
				+ ", parentBuName=" + parentBuName + ", buName=" + buName + ", location=" + location + ", country="
				+ country + ", loginId=" + loginId + ", supervisorId=" + supervisorId + ", birthDate=" + birthDate
				+ ", joiningDate=" + joiningDate + ", profilePicUrl=" + profilePicUrl + ", payroll=" + payroll
				+ ", jobTitle=" + jobTitle + ", band=" + band + ", activeSatus=" + activeSatus + ", sourceUserId="
				+ sourceUserId + ", previousExp=" + previousExp + ", bloodGroup=" + bloodGroup + ", city=" + city
				+ ", vbu=" + vbu + ", totalExp=" + totalExp + ", skills=" + skills + ", awards=" + awards
				+ ", training=" + training + ", arName=" + arName + ", subPracticeName=" + subPracticeName
				+ ", practiceName=" + practiceName + ", arEmailId=" + arEmailId + ", arId=" + arId + ", hiredBg="
				+ hiredBg + ", department=" + department + ", terminationDate=" + terminationDate
				+ ", terminationNotificationDate=" + terminationNotificationDate + "]";
	}
	
}
