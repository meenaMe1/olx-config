package com.zensar.beans;

import org.springframework.stereotype.Component;

@Component
public class RequestBodyDo {

	private int userId;
	private String path;
	private int year;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	
}
