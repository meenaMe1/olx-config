package com.zensar.dao;

import java.util.List;

import com.zensar.beans.UserDo;

public interface UserDao {

	public List<UserDo> userDetails(int userId);
	public List<UserDo> listOfEmployees(int year);
}
