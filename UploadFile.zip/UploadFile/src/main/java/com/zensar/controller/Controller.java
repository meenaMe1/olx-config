package com.zensar.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class Controller {

	@PostMapping("/uploadFile")
	public String uploadFile(@RequestParam(value = "uploadFile", required = false) MultipartFile multipartFile,@RequestParam("userId") Integer userId) {
		Path fileStorageLocation = Paths.get("D:\\Image\\" + userId).toAbsolutePath().normalize();
		File file = new File("D:\\Image\\" + userId.toString());
		if (!file.exists()) {
			file.mkdirs();
			try {
				Files.createDirectories(fileStorageLocation);
			} catch (Exception e) {
				e.printStackTrace();
			}
			String originalFileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			String fileName = "";
			String fileExtension = "";
			try {
				fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
			} catch (Exception e) {
				fileExtension = "";
			}
			fileName = userId + fileExtension;
			Path targetLocation = fileStorageLocation.resolve(fileName);
			try {
				Files.copy(multipartFile.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return   fileName+" Uploaded Successfully \nFile Path - "+file.getPath();
		} else {
			return "File Already Exist \nFile Path - "+file.getPath();
		}
	}

	@PostMapping("/deleteFile")
	public String deleteFile(@RequestParam("filePath") String filePath) {
		File file = new File(filePath);
		if(file.exists()) {
			try {
				FileUtils.deleteDirectory(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return "File Deleted Successfully";
		}
		else {
		return "File doesn't Exist on given path - "+filePath;
		}
	}
}
