package com.app.model.user;

public enum Role {
    USER, ADMIN
}
