<!-- Love angular-springboot-rest-jwt? Please consider supporting our collective:
👉  https://opencollective.com/angular-springboot-rest-jwt/donate -->