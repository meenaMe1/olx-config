package com.zensar.zenquestions.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.zenquestions.beans.Question;
import com.zensar.zenquestions.repository.SchedulerRepository;
import com.zensar.zenquestions.service.SchedulerService;

@Service
public class ServiceImpl implements SchedulerService {

	@Autowired
	SchedulerRepository repo;
	
	@Override
	public Question insertQuestion() {
		return repo.insertQuestion();
	}

}
