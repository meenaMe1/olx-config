package com.zensar.zenquestions.service;

import com.zensar.zenquestions.beans.Question;

public interface SchedulerService {

	Question insertQuestion();

}
