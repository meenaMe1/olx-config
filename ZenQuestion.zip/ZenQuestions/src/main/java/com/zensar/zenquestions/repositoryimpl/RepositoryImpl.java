package com.zensar.zenquestions.repositoryimpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zensar.zenquestions.beans.Question;
import com.zensar.zenquestions.repository.SchedulerRepository;

@Repository
@Transactional(noRollbackFor = Exception.class)
public class RepositoryImpl implements SchedulerRepository {

	@Autowired
	private EntityManagerFactory entityManager;
	@Autowired
	private com.zensar.zenquestions.constants.QueryConstants queryConstants;
	@PersistenceContext(unitName = "MYSQL_DB")
	private EntityManager mySqlSession;

	@Override
	public Question insertQuestion() {
		EntityManager session = entityManager.createEntityManager();
		List<Question> questionList = new ArrayList<>();
		Question questions = null;
		try {
			List<Object[]> resultSet = session.createNativeQuery(queryConstants.getQuestion()).getResultList();
			for (Object[] result : resultSet) {
				questions = new Question();
				questions.setQuestionId((int) result[0]);
				questions.setQuestion(result[1] != null ? ((String) result[1]).trim() : "");
				questions.setStatus(result[2] != null ? ((String) result[2]).trim() : "");
				questions.setRaisedDate((Timestamp) result[3]);
				questions.setRaisedByName(result[4] != null ? ((String) result[4]).trim() : "");
				questions.setRaisedById(result[5] != null ? (int) result[5] : 0);
				questions.setTagDate((Timestamp) result[6]);
				questions.setTaggedToName(result[7] != null ? ((String) result[7]).trim() : "");
				questions.setTaggedId(result[8] != null ? (int) result[8] : 0);
				questions.setAnswerById(result[9] != null ? (int) result[9] : 0);
				questions.setAnswerByName(result[10] != null ? ((String) result[10]).trim() : "");
				questions.setAnswer(result[11] != null ? ((String) result[11]).trim() : "");
				questions.setGroupName(result[12] != null ? ((String) result[12]).trim() : "");
				questionList.add(questions);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (session.isOpen())
				session.close();
		}
		int result = 0;
		Iterator itr = questionList.iterator();
		while (itr.hasNext()) {
			questions = (Question) itr.next();
			try {
				/*
				 * result = mySqlSession.createNativeQuery(queryConstants.getInsertQuestion())
				 * .setParameter("questionId", questions.getQuestionId())
				 * .setParameter("question", questions.getQuestion()) .setParameter("status",
				 * questions.getStatus()) .setParameter("raisedDate", questions.getRaisedDate())
				 * .setParameter("raisedByName", questions.getRaisedByName())
				 * .setParameter("raisedById", questions.getRaisedById())
				 * .setParameter("tagDate", questions.getTagDate())
				 * .setParameter("taggedToName", questions.getTaggedToName())
				 * .setParameter("taggedId", questions.getTaggedId())
				 * .setParameter("answerById", questions.getAnswerById())
				 * .setParameter("answerByName", questions.getAnswerByName())
				 * .setParameter("answer", questions.getAnswer()) .setParameter("groupName",
				 * questions.getGroupName()) .executeUpdate();
				 */
				System.out.println(questions.getQuestion());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				if (session.isOpen())
					session.close();
			}
		}
		return questions;
	}

}
