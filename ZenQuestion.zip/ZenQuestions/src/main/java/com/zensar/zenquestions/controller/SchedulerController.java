package com.zensar.zenquestions.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.zenquestions.beans.Question;
import com.zensar.zenquestions.service.SchedulerService;

@RestController
@RequestMapping("/zenquestion")
public class SchedulerController {
	
	@Autowired
	SchedulerService service;

	@GetMapping("/insert")
	@Scheduled(cron = "*/5 * * * * *")
	public Question insertQuestion() {
		return service.insertQuestion();
	}
}
