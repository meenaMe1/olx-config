package com.zensar.zenquestions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
//@EnableScheduling
public class ZenSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZenSearchApplication.class, args);
	}

}
