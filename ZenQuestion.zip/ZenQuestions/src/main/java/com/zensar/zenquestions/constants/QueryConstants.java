package com.zensar.zenquestions.constants;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:exit-zentalent-queries.properties"})
@ConfigurationProperties
public class QueryConstants {

	private String question;
	private String insertQuestion;

	
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getInsertQuestion() {
		return insertQuestion;
	}

	public void setInsertQuestion(String insertQuestion) {
		this.insertQuestion = insertQuestion;
	}
	
}
