package com.zensar.zenquestions.beans;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

@Component
public class Question {

	private int questionId;
	private String question;
	private String status;
	private Timestamp raisedDate;
	private String raisedByName;
	private int raisedById;
	private Timestamp tagDate;
	private String taggedToName;
	private int taggedId;
	private int answerById;
	private String answerByName;
	private String answer;
	private String groupName;
	
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getRaisedDate() {
		return raisedDate;
	}
	public void setRaisedDate(Timestamp raisedDate) {
		this.raisedDate = raisedDate;
	}
	public String getRaisedByName() {
		return raisedByName;
	}
	public void setRaisedByName(String raisedByName) {
		this.raisedByName = raisedByName;
	}
	public int getRaisedById() {
		return raisedById;
	}
	public void setRaisedById(int raisedById) {
		this.raisedById = raisedById;
	}
	public Timestamp getTagDate() {
		return tagDate;
	}
	public void setTagDate(Timestamp tagDate) {
		this.tagDate = tagDate;
	}
	public String getTaggedToName() {
		return taggedToName;
	}
	public void setTaggedToName(String taggedToName) {
		this.taggedToName = taggedToName;
	}
	public int getTaggedId() {
		return taggedId;
	}
	public void setTaggedId(int taggedId) {
		this.taggedId = taggedId;
	}
	public int getAnswerById() {
		return answerById;
	}
	public void setAnswerById(int answerById) {
		this.answerById = answerById;
	}
	public String getAnswerByName() {
		return answerByName;
	}
	public void setAnswerByName(String answerByName) {
		this.answerByName = answerByName;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", question=" + question + ", status=" + status + ", raisedDate="
				+ raisedDate + ", raisedByName=" + raisedByName + ", raisedById=" + raisedById + ", tagDate=" + tagDate
				+ ", taggedToName=" + taggedToName + ", taggedId=" + taggedId + ", answerById=" + answerById
				+ ", answerByName=" + answerByName + ", answer=" + answer + ", groupName=" + groupName + "]";
	}
	
}
