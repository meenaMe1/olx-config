package com.zensar.zenquestions.repository;

import com.zensar.zenquestions.beans.Question;

public interface SchedulerRepository {

	Question insertQuestion();

}
