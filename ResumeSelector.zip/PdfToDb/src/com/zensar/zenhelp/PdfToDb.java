package com.zensar.zenhelp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class PdfToDb {

	public static void main(String[] args) {
		String[] skills = { "SQL", "Java", "HTML", "CSS", "C", "C++", "ASP.NET", "Spring", "Hibernate", "XML", "Linux", "QuickBooks" };
		PdfReader reader;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://10.42.206.146:3306/ZenTalent", "tazdevuser", "Cv9@9PLj");
			String query = "INSERT INTO PdfDetails(content) VALUES(?);";
			PreparedStatement ps = conn.prepareStatement(query);

			reader = new PdfReader("C:/Users/sp61808/Downloads/resume.pdf");
			int pages = reader.getNumberOfPages();
			String text = "";
			List<String> list = new ArrayList<>();
			for (int i = 1; i <= pages; i++) {
				text = text.concat(PdfTextExtractor.getTextFromPage(reader, i));
			}
			System.out.println(text);
			
			StringTokenizer multiTokenizer = new StringTokenizer(text, ",://.- ");
			while (multiTokenizer.hasMoreTokens()) {
				list.add(multiTokenizer.nextToken());
			}

			int count = 0;
			for (int i = 0; i < skills.length; i++) {
				if (list.contains(skills[i])) {
					System.out.println("True " + skills[i]);
					count++;
				} else {
					System.out.println("False " + skills[i]);
				}
			}
			if (count >= 1) {
				System.out.println("SELECTED");
				ps.setString(1, text);
				ps.executeUpdate();
			} else {
				System.out.println("REJECTED");
			}
			conn.close();
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
