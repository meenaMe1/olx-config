package com.spring.test.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="*")
public class UserController {
	

	@GetMapping("/user")
	public String viewUser() {
	return "Hello User";
	}

	 @GetMapping("/manager")
	public String viewManager() {
	return "Hello Manager";
	}

	 @GetMapping("/admin")
	public String viewAdmin() {
	return "Hello Admin";
	}
	 
	 
	 @GetMapping("/home")
		public String viewHome() {
		return "Hello Welcome to Home Page";
		}
	
	
	
}
