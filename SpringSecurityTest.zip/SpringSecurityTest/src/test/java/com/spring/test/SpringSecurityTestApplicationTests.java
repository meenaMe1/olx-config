package com.spring.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
